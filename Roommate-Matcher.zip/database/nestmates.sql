CREATE DATABASE IF NOT EXISTS nestmates;

USE nestmates;

CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS profiles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL UNIQUE,

    name VARCHAR(100) NOT NULL,
    bio TEXT,
    location VARCHAR(150),
    age INT,
    occupation VARCHAR(150),

    sleep_schedule VARCHAR(50),
    cleanliness_level VARCHAR(50),
    smoking VARCHAR(20),
    pets VARCHAR(20),

    budget_min INT DEFAULT 8000,
    budget_max INT DEFAULT 25000,
    gender VARCHAR(20) DEFAULT 'Any',
    preferred_location VARCHAR(150) DEFAULT 'Any',
    move_in_date VARCHAR(50) DEFAULT 'Flexible',
    avatar_emoji VARCHAR(10) DEFAULT '👨🏻',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS matches (
    id INT PRIMARY KEY AUTO_INCREMENT,

    user_id INT NOT NULL,
    matched_user_id INT NOT NULL,

    compatibility_score DECIMAL(5,2) DEFAULT 0,

    status VARCHAR(30) DEFAULT 'ACTIVE',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE,

    FOREIGN KEY (matched_user_id)
        REFERENCES users(id)
        ON DELETE CASCADE,

    UNIQUE(user_id, matched_user_id)
);

CREATE TABLE IF NOT EXISTS requests (
    id INT PRIMARY KEY AUTO_INCREMENT,

    sender_id INT NOT NULL,
    receiver_id INT NOT NULL,

    status VARCHAR(30) DEFAULT 'PENDING',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (sender_id)
        REFERENCES users(id)
        ON DELETE CASCADE,

    FOREIGN KEY (receiver_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);
