# Roommate Matcher

A Java college mini project for finding compatible roommates. Students can create an account, build a lifestyle profile, browse potential roommates, and send or respond to connection requests.

## Project credit

This is a separate college-project version adapted from the Nestmates project shared by [@nikhil00011-hash](https://github.com/nikhil00011-hash). The visible app name and project packaging were updated for this version; the original project remains separate.

## Technology

- Java 17, Jakarta Servlets, JSP, and embedded Tomcat
- MySQL
- Maven and Docker

## Run locally

1. Create a MySQL database and configure `NESTMATES_DB_URL`, `NESTMATES_DB_USER`, and `NESTMATES_DB_PASSWORD` in your environment.
2. Run `mvn clean package`.
3. Start with `java -jar build/roommate-matcher-for-friends.war`.
4. Open `http://localhost:8080`.

The app creates its tables when it starts. The SQL schema is also available in `database/nestmates.sql`.

## Deploy the application

The Dockerfile is configured for Railway. Add a MySQL service, then configure the web service with private Railway variable references for its host, port, database, user, and password. Railway assigns `PORT` for the web process. Never commit credentials or `.env` files.

Pushing this repository to GitHub stores the source code; it does not host the Java application. A Java host and MySQL database are needed to run the live app.

## Demo note

Use a demo account and sample roommate profiles when presenting. Do not enter real student contact details or passwords into a public demo.
