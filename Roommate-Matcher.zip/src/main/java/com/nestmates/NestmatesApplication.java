package com.nestmates;

public final class NestmatesApplication {
    private NestmatesApplication() {
    }
}
