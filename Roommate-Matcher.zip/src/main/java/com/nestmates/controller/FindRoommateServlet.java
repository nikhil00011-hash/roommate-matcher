package com.nestmates.controller;

import com.nestmates.dao.ProfileDAO;
import com.nestmates.dao.RequestDAO;
import com.nestmates.util.MatchScoreUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class FindRoommateServlet extends HttpServlet {

    private ProfileDAO profileDAO;
    private RequestDAO requestDAO;

    @Override
    public void init() {
        profileDAO = new ProfileDAO();
        requestDAO = new RequestDAO();
    }

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        int currentUserId;
        try {
            currentUserId = Integer.parseInt(session.getAttribute("userId").toString());
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        // Get current user's profile and candidate profiles
        Map<String, Object> currentProfile = profileDAO.getProfile(currentUserId);
        List<Map<String, Object>> profiles = profileDAO.getOtherProfiles(currentUserId);
        Map<Integer, String> sentRequestStatuses = requestDAO.getSentRequestStatuses(currentUserId);

        // Filter Query Parameters
        String searchQuery = request.getParameter("search");
        String locationFilter = request.getParameter("location");
        String minScoreText = request.getParameter("minScore");
        String sleepFilter = request.getParameter("sleepSchedule");
        String cleanlinessFilter = request.getParameter("cleanliness");
        String maxBudgetText = request.getParameter("maxBudget");

        int minScore = 0;
        int maxBudget = 99999;
        try { if (minScoreText != null) minScore = Integer.parseInt(minScoreText.trim()); } catch (Exception ignored) {}
        try { if (maxBudgetText != null) maxBudget = Integer.parseInt(maxBudgetText.trim()); } catch (Exception ignored) {}

        List<Map<String, Object>> filteredProfiles = new ArrayList<>();

        if (profiles != null) {
            for (Map<String, Object> profile : profiles) {

                // Calculate multi-factor compatibility score
                int score = (currentProfile != null) ? MatchScoreUtil.calculateMatchScore(currentProfile, profile) : 50;
                profile.put("matchScore", score);

                int profileUserId = (Integer) profile.get("userId");
                profile.put("requestStatus", sentRequestStatuses.get(profileUserId));

                // 1. Min Score Filter
                if (score < minScore) continue;

                // 2. Search Query (Name, Occupation, Location, Bio)
                if (searchQuery != null && !searchQuery.isBlank()) {
                    String q = searchQuery.trim().toLowerCase();
                    String name = String.valueOf(profile.getOrDefault("name", "")).toLowerCase();
                    String occ = String.valueOf(profile.getOrDefault("occupation", "")).toLowerCase();
                    String loc = String.valueOf(profile.getOrDefault("location", "")).toLowerCase();
                    String bio = String.valueOf(profile.getOrDefault("bio", "")).toLowerCase();

                    if (!name.contains(q) && !occ.contains(q) && !loc.contains(q) && !bio.contains(q)) {
                        continue;
                    }
                }

                // 3. Location Filter
                if (locationFilter != null && !locationFilter.isBlank() && !"Any".equalsIgnoreCase(locationFilter)) {
                    String loc = String.valueOf(profile.getOrDefault("location", "")).toLowerCase();
                    if (!loc.contains(locationFilter.trim().toLowerCase())) {
                        continue;
                    }
                }

                // 4. Sleep Schedule Filter
                if (sleepFilter != null && !sleepFilter.isBlank() && !"Any".equalsIgnoreCase(sleepFilter)) {
                    String sleep = String.valueOf(profile.getOrDefault("sleepSchedule", ""));
                    if (!sleep.equalsIgnoreCase(sleepFilter.trim())) {
                        continue;
                    }
                }

                // 5. Cleanliness Filter
                if (cleanlinessFilter != null && !cleanlinessFilter.isBlank() && !"Any".equalsIgnoreCase(cleanlinessFilter)) {
                    String clean = String.valueOf(profile.getOrDefault("cleanliness", ""));
                    if (!clean.equalsIgnoreCase(cleanlinessFilter.trim())) {
                        continue;
                    }
                }

                // 6. Max Budget Filter
                int candidateMinBudget = 500;
                try { candidateMinBudget = Integer.parseInt(profile.getOrDefault("budgetMin", 500).toString()); } catch (Exception ignored) {}
                if (candidateMinBudget > maxBudget) {
                    continue;
                }

                filteredProfiles.add(profile);
            }
        }

        // Sort candidates by matchScore DESC
        filteredProfiles.sort((p1, p2) -> Integer.compare(
                (Integer) p2.getOrDefault("matchScore", 0),
                (Integer) p1.getOrDefault("matchScore", 0)
        ));

        String csrfToken = (String) session.getAttribute("csrfToken");
        if (csrfToken == null) {
            csrfToken = UUID.randomUUID().toString();
            session.setAttribute("csrfToken", csrfToken);
        }

        request.setAttribute("csrfToken", csrfToken);
        request.setAttribute("flashType", session.getAttribute("flashType"));
        request.setAttribute("flashMessage", session.getAttribute("flashMessage"));
        session.removeAttribute("flashType");
        session.removeAttribute("flashMessage");

        request.setAttribute("profiles", filteredProfiles);
        request.setAttribute("totalCount", profiles != null ? profiles.size() : 0);
        request.setAttribute("searchQuery", searchQuery != null ? searchQuery : "");
        request.setAttribute("locationFilter", locationFilter != null ? locationFilter : "Any");
        request.setAttribute("minScoreFilter", minScore);
        request.setAttribute("sleepFilter", sleepFilter != null ? sleepFilter : "Any");
        request.setAttribute("cleanlinessFilter", cleanlinessFilter != null ? cleanlinessFilter : "Any");

        request.getRequestDispatcher("/find-roommate.jsp").forward(request, response);
    }
}
