package com.nestmates.controller;

import com.nestmates.dao.RequestDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public class HandleRequestServlet extends HttpServlet {

    private RequestDAO requestDAO;

    @Override
    public void init() {
        requestDAO = new RequestDAO();
    }

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null ||
                session.getAttribute("userId") == null) {

            response.sendRedirect(
                    request.getContextPath() + "/login.jsp"
            );
            return;
        }

        int userId = Integer.parseInt(
                session.getAttribute("userId").toString()
        );

        String sessionToken =
                (String) session.getAttribute("csrfToken");

        String submittedToken =
                request.getParameter("csrfToken");

        if (!tokensMatch(sessionToken, submittedToken)) {
            setFlash(session, "error",
                    "Your page expired. Please try again.");
            redirectToRequests(request, response);
            return;
        }

        int requestId;
        String action = request.getParameter("action");

        try {
            requestId = Integer.parseInt(
                    request.getParameter("requestId")
            );
        } catch (Exception e) {
            setFlash(session, "error",
                    "Invalid request.");
            redirectToRequests(request, response);
            return;
        }

        boolean updated;

        if ("accept".equalsIgnoreCase(action)) {
            updated = requestDAO.updateRequestStatus(
                    requestId, userId, "ACCEPTED");
            setFlash(session, updated ? "success" : "error",
                    updated
                            ? "Request accepted. You are now connected!"
                            : "Could not accept that request.");
        } else if ("decline".equalsIgnoreCase(action)) {
            updated = requestDAO.updateRequestStatus(
                    requestId, userId, "DECLINED");
            setFlash(session, updated ? "success" : "error",
                    updated
                            ? "Request declined."
                            : "Could not decline that request.");
        } else {
            setFlash(session, "error", "Unknown action.");
        }

        redirectToRequests(request, response);
    }

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        redirectToRequests(request, response);
    }

    private boolean tokensMatch(
            String expected,
            String submitted) {

        return expected != null && submitted != null &&
                MessageDigest.isEqual(
                        expected.getBytes(StandardCharsets.UTF_8),
                        submitted.getBytes(StandardCharsets.UTF_8)
                );
    }

    private void setFlash(
            HttpSession session,
            String type,
            String message) {

        session.setAttribute("flashType", type);
        session.setAttribute("flashMessage", message);
    }

    private void redirectToRequests(
            HttpServletRequest request,
            HttpServletResponse response)
            throws IOException {

        response.sendRedirect(
                request.getContextPath() + "/requests"
        );
    }
}
