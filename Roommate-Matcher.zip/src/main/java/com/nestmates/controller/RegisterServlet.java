package com.nestmates.controller;

import com.nestmates.util.DatabaseErrors;
import com.nestmates.dao.UserDAO;
import com.nestmates.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.mindrot.jbcrypt.BCrypt;

import java.io.IOException;
import java.sql.SQLException;
import java.util.regex.Pattern;

public class RegisterServlet extends HttpServlet {

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        String normalizedEmail = email == null ? "" : email.trim();

        if (normalizedEmail.isEmpty() || password == null ||
                password.isBlank()) {

            response.sendRedirect(
                    request.getContextPath()
                            + "/register.jsp?error=Please+fill+all+fields");
            return;
        }

        if (!EMAIL_PATTERN.matcher(normalizedEmail).matches()) {
            response.sendRedirect(
                    request.getContextPath()
                            + "/register.jsp?error=Please+enter+a+valid+email");
            return;
        }

        if (password.length() < 8) {
            response.sendRedirect(
                    request.getContextPath()
                            + "/register.jsp?error=Password+must+be+at+least+8+characters");
            return;
        }

        try {
            boolean created = new UserDAO().registerUser(new User(normalizedEmail.toLowerCase(),
                    BCrypt.hashpw(password, BCrypt.gensalt(12))));
            if (!created) {
                response.sendRedirect(request.getContextPath() + "/register.jsp?error=Email+already+registered");
                return;
            }
            response.sendRedirect(
                    request.getContextPath()
                            + "/login.jsp?success=Account+created");
        } catch (SQLException e) {
            getServletContext().log("Could not register because the database is unavailable.", e);
            response.sendRedirect(
                    request.getContextPath()
                            + "/register.jsp?error="
                            + DatabaseErrors.urlEncodedSignInMessage(e));
        }
    }
}