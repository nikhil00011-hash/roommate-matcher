package com.nestmates.controller;

import com.nestmates.dao.RequestDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class RequestsServlet extends HttpServlet {

    private RequestDAO requestDAO;

    @Override
    public void init() {
        requestDAO = new RequestDAO();
    }

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null ||
                session.getAttribute("userId") == null) {

            response.sendRedirect(
                    request.getContextPath() + "/login.jsp"
            );
            return;
        }

        int userId;
        try {
            userId = Integer.parseInt(
                    session.getAttribute("userId").toString()
            );
        } catch (RuntimeException exception) {
            session.invalidate();
            response.sendRedirect(
                    request.getContextPath() + "/login.jsp"
            );
            return;
        }

        List<Map<String, Object>> incoming =
                requestDAO.getIncomingRequests(userId);

        List<Map<String, Object>> sent =
                requestDAO.getSentRequests(userId);

        String csrfToken =
                (String) session.getAttribute("csrfToken");

        if (csrfToken == null) {
            csrfToken = UUID.randomUUID().toString();
            session.setAttribute("csrfToken", csrfToken);
        }

        request.setAttribute("csrfToken", csrfToken);
        request.setAttribute("incomingRequests", incoming);
        request.setAttribute("sentRequests", sent);
        request.setAttribute(
                "flashType",
                session.getAttribute("flashType")
        );
        request.setAttribute(
                "flashMessage",
                session.getAttribute("flashMessage")
        );

        session.removeAttribute("flashType");
        session.removeAttribute("flashMessage");

        request.getRequestDispatcher("/requests.jsp")
                .forward(request, response);
    }
}
