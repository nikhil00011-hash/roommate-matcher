package com.nestmates.controller;

import com.nestmates.util.DatabaseErrors;
import com.nestmates.util.SecurityUtil;
import com.nestmates.dao.UserDAO;
import com.nestmates.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.mindrot.jbcrypt.BCrypt;

import java.io.IOException;
import java.sql.SQLException;

public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        if (email == null || password == null ||
                email.isBlank() || password.isBlank()) {

            response.sendRedirect(
                    request.getContextPath()
                            + "/login.jsp?error=Please+fill+all+fields"
            );
            return;
        }

        try {
            User user = new UserDAO().findByEmail(email.trim().toLowerCase());
            if (user == null || !BCrypt.checkpw(password, user.getPasswordHash())) {
                response.sendRedirect(request.getContextPath() + "/login.jsp?error=Invalid+email+or+password");
                return;
            }
            SecurityUtil.startSession(request, user.getId(), user.getEmail());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        } catch (SQLException e) {
            getServletContext().log("Could not sign in because the database is unavailable.", e);
            response.sendRedirect(
                    request.getContextPath()
                            + "/login.jsp?error="
                            + DatabaseErrors.urlEncodedSignInMessage(e)
            );
            return;
        }
    }
}