package com.nestmates.controller;

import com.nestmates.util.SecurityUtil;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

public final class SecurityHeadersFilter implements Filter {
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        if (response instanceof HttpServletResponse http) SecurityUtil.securityHeaders(http);
        chain.doFilter(request, response);
    }
}
