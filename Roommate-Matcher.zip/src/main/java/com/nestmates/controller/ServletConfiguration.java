package com.nestmates.controller;

/**
 * Servlet registrations are declared in web.xml. This project uses Jakarta
 * Servlets with embedded Tomcat and does not depend on Spring Boot.
 */
public final class ServletConfiguration {
    private ServletConfiguration() {}
}
