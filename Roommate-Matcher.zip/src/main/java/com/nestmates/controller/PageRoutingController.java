package com.nestmates.controller;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Redirects legacy .html URLs to the live JSP/servlet equivalents.
 * Mapped via web.xml for: dashboard.html, find-roommate.html, profile.html, index.html
 */
public class PageRoutingController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        String path = request.getServletPath();

        String target;
        if (path.endsWith("dashboard.html")) {
            target = "/dashboard";
        } else if (path.endsWith("find-roommate.html")) {
            target = "/find-roommate";
        } else if (path.endsWith("profile.html")) {
            target = "/profile";
        } else {
            target = "/index.jsp";   // index.html → landing page
        }

        response.sendRedirect(request.getContextPath() + target);
    }
}
