package com.nestmates.controller;

import com.nestmates.util.DatabaseErrors;
import com.nestmates.dao.UserDAO;
import com.nestmates.model.User;
import com.nestmates.util.SecurityUtil;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.mindrot.jbcrypt.BCrypt;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class AuthController extends HttpServlet {
    private static final Pattern EMAIL = Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String body = new String(request.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
        Map<String, String> fields = parseStringObject(body);
        if (fields == null) {
            json(response, HttpServletResponse.SC_BAD_REQUEST, false,
                    "Request body must be a JSON object with string email and password fields.", null);
            return;
        }
        String email = fields.getOrDefault("email", "").trim().toLowerCase();
        String password = fields.getOrDefault("password", "");
        if (email.isEmpty() || password.isEmpty() || !EMAIL.matcher(email).matches()) {
            json(response, HttpServletResponse.SC_BAD_REQUEST, false,
                    "Enter a valid email address and password.", null);
            return;
        }
        if (request.getServletPath().endsWith("/register")) {
            register(response, email, password);
        } else {
            login(request, response, email, password);
        }
    }

    private void register(HttpServletResponse response, String email, String password)
            throws IOException {
        if (password.length() < 8) {
            json(response, HttpServletResponse.SC_BAD_REQUEST, false,
                    "Password must contain at least 8 characters.", null);
            return;
        }
        try {
            boolean created = new UserDAO().registerUser(
                    new User(email, BCrypt.hashpw(password, BCrypt.gensalt(12))));
            json(response, created ? HttpServletResponse.SC_CREATED : HttpServletResponse.SC_CONFLICT,
                    created, created ? "Account created successfully." : "This email is already registered.", null);
        } catch (SQLException exception) {
            json(response, HttpServletResponse.SC_SERVICE_UNAVAILABLE, false,
                    DatabaseErrors.signInMessage(exception), null);
        }
    }

    private void login(HttpServletRequest request, HttpServletResponse response,
                       String email, String password) throws IOException {
        try {
            User user = new UserDAO().findByEmail(email);
            if (user == null || !BCrypt.checkpw(password, user.getPasswordHash())) {
                json(response, HttpServletResponse.SC_UNAUTHORIZED, false,
                        "Invalid email or password.", null);
                return;
            }
            HttpSession session = SecurityUtil.startSession(request, user.getId(), user.getEmail());
            json(response, HttpServletResponse.SC_OK, true, "Signed in successfully.", user.getId());
        } catch (SQLException exception) {
            json(response, HttpServletResponse.SC_SERVICE_UNAVAILABLE, false,
                    DatabaseErrors.signInMessage(exception), null);
        }
    }

    private Map<String, String> parseStringObject(String json) {
        if (json == null) return null;
        int index = skipWhitespace(json, 0);
        if (index >= json.length() || json.charAt(index++) != '{') return null;

        Map<String, String> values = new HashMap<>();
        while (true) {
            index = skipWhitespace(json, index);
            if (index < json.length() && json.charAt(index) == '}') {
                return skipWhitespace(json, index + 1) == json.length() ? values : null;
            }

            ParsedString key = parseString(json, index);
            if (key == null) return null;
            index = skipWhitespace(json, key.nextIndex());
            if (index >= json.length() || json.charAt(index++) != ':') return null;

            ParsedString value = parseString(json, skipWhitespace(json, index));
            if (value == null) return null;
            values.put(key.value(), value.value());
            index = skipWhitespace(json, value.nextIndex());
            if (index >= json.length()) return null;
            char separator = json.charAt(index++);
            if (separator == '}') {
                return skipWhitespace(json, index) == json.length() ? values : null;
            }
            if (separator != ',') return null;
        }
    }

    private ParsedString parseString(String json, int start) {
        if (start >= json.length() || json.charAt(start) != '"') return null;
        StringBuilder value = new StringBuilder();
        for (int index = start + 1; index < json.length(); index++) {
            char character = json.charAt(index);
            if (character == '"') return new ParsedString(value.toString(), index + 1);
            if (character < 0x20) return null;
            if (character != '\\') {
                value.append(character);
                continue;
            }
            if (++index >= json.length()) return null;
            char escaped = json.charAt(index);
            switch (escaped) {
                case '"', '\\', '/' -> value.append(escaped);
                case 'b' -> value.append('\b');
                case 'f' -> value.append('\f');
                case 'n' -> value.append('\n');
                case 'r' -> value.append('\r');
                case 't' -> value.append('\t');
                case 'u' -> {
                    if (index + 4 >= json.length()) return null;
                    try {
                        value.append((char) Integer.parseInt(json.substring(index + 1, index + 5), 16));
                    } catch (NumberFormatException exception) {
                        return null;
                    }
                    index += 4;
                }
                default -> { return null; }
            }
        }
        return null;
    }

    private int skipWhitespace(String value, int index) {
        while (index < value.length() && Character.isWhitespace(value.charAt(index))) index++;
        return index;
    }

    private record ParsedString(String value, int nextIndex) {
    }

    private void json(HttpServletResponse response, int status, boolean success,
                      String message, Integer userId) throws IOException {
        response.setStatus(status);
        response.setContentType("application/json;charset=UTF-8");
        String userPart = userId == null ? "" : ",\"userId\":" + userId;
        response.getWriter().write("{\"success\":" + success + ",\"message\":\""
                + escapeJson(message) + "\"" + userPart + "}");
    }

    private String escapeJson(String value) {
        StringBuilder escaped = new StringBuilder();
        for (int index = 0; index < value.length(); index++) {
            char character = value.charAt(index);
            switch (character) {
                case '"' -> escaped.append("\\\"");
                case '\\' -> escaped.append("\\\\");
                case '\b' -> escaped.append("\\b");
                case '\f' -> escaped.append("\\f");
                case '\n' -> escaped.append("\\n");
                case '\r' -> escaped.append("\\r");
                case '\t' -> escaped.append("\\t");
                default -> {
                    if (character < 0x20) escaped.append(String.format("\\u%04x", (int) character));
                    else escaped.append(character);
                }
            }
        }
        return escaped.toString();
    }
}
