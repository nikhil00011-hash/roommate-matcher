package com.nestmates.controller;

import com.nestmates.dao.ProfileDAO;
import com.nestmates.dao.RequestDAO;
import com.nestmates.util.MatchScoreUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class DashboardServlet extends HttpServlet {

    private ProfileDAO profileDAO;
    private RequestDAO requestDAO;

    @Override
    public void init() {
        profileDAO = new ProfileDAO();
        requestDAO = new RequestDAO();
    }

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null ||
                session.getAttribute("userId") == null) {

            response.sendRedirect(
                    request.getContextPath() + "/login.jsp"
            );
            return;
        }

        int userId;
        try {
            userId = Integer.parseInt(
                    session.getAttribute("userId").toString()
            );
        } catch (RuntimeException exception) {
            session.invalidate();
            response.sendRedirect(
                    request.getContextPath() + "/login.jsp"
            );
            return;
        }

        Map<String, Object> currentProfile =
                profileDAO.getProfile(userId);

        List<Map<String, Object>> others =
                profileDAO.getOtherProfiles(userId);

        int profileProgress =
                MatchScoreUtil.profileProgress(currentProfile);

        int matchCount = others == null ? 0 : others.size();
        int pendingRequests =
                requestDAO.countPendingIncoming(userId);

        Map<String, Object> topMatch = null;
        int topScore = -1;

        if (currentProfile != null && others != null) {

            for (Map<String, Object> profile : others) {

                int score = MatchScoreUtil.calculateMatchScore(
                        currentProfile,
                        profile
                );

                if (score > topScore) {
                    topScore = score;
                    topMatch = profile;
                }
            }
        }

        String csrfToken =
                (String) session.getAttribute("csrfToken");

        if (csrfToken == null) {
            csrfToken = UUID.randomUUID().toString();
            session.setAttribute("csrfToken", csrfToken);
        }

        request.setAttribute("csrfToken", csrfToken);
        request.setAttribute("profileProgress", profileProgress);
        request.setAttribute("matchCount", matchCount);
        request.setAttribute("pendingRequests", pendingRequests);
        request.setAttribute("topMatch", topMatch);
        request.setAttribute("topMatchScore", Math.max(topScore, 0));
        request.setAttribute("hasProfile", currentProfile != null);

        request.getRequestDispatcher("/dashboard.jsp")
                .forward(request, response);
    }
}
