package com.nestmates.controller;

import com.nestmates.dao.RequestDAO;
import com.nestmates.dao.RequestDAO.SendRequestResult;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public class SendRequestServlet extends HttpServlet {

    private RequestDAO requestDAO;

    @Override
    public void init() {
        requestDAO = new RequestDAO();
    }

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null ||
                session.getAttribute("userId") == null) {

            response.sendRedirect(
                    request.getContextPath() + "/login.jsp"
            );
            return;
        }

        int senderId;
        int receiverId;

        try {
            senderId = Integer.parseInt(
                    session.getAttribute("userId").toString()
            );

            receiverId = Integer.parseInt(
                    request.getParameter("receiverId")
            );

        } catch (Exception e) {
            setFlash(session, "error",
                    "Could not identify that roommate.");
            redirectToFindRoommate(request, response);
            return;
        }

        String sessionToken =
                (String) session.getAttribute("csrfToken");

        String submittedToken = request.getParameter("csrfToken");

        if (!tokensMatch(sessionToken, submittedToken)) {
            setFlash(session, "error",
                    "Your page expired. Please try again.");
            redirectToFindRoommate(request, response);
            return;
        }

        SendRequestResult result;

        try {
            result = requestDAO.sendRequest(senderId, receiverId);

        } catch (RuntimeException e) {
            setFlash(session, "error",
                    "Could not send the request. Please try again.");
            redirectToFindRoommate(request, response);
            return;
        }

        switch (result) {
            case CREATED -> setFlash(session, "success",
                    "Roommate request sent successfully.");
            case ALREADY_SENT -> setFlash(session, "info",
                    "You have already sent this roommate request.");
            case INCOMING_REQUEST -> setFlash(session, "info",
                    "This person has already sent you a request.");
            case ALREADY_CONNECTED -> setFlash(session, "info",
                    "You are already connected with this roommate.");
            case RECEIVER_NOT_FOUND, INVALID -> setFlash(session, "error",
                    "That roommate is no longer available.");
        }

        redirectToFindRoommate(request, response);
    }

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        redirectToFindRoommate(request, response);
    }

    private boolean tokensMatch(
            String expected,
            String submitted) {

        return expected != null && submitted != null &&
                MessageDigest.isEqual(
                        expected.getBytes(StandardCharsets.UTF_8),
                        submitted.getBytes(StandardCharsets.UTF_8)
                );
    }

    private void setFlash(
            HttpSession session,
            String type,
            String message) {

        session.setAttribute("flashType", type);
        session.setAttribute("flashMessage", message);
    }

    private void redirectToFindRoommate(
            HttpServletRequest request,
            HttpServletResponse response)
            throws IOException {

        response.sendRedirect(
                request.getContextPath() + "/find-roommate"
        );
    }
}
