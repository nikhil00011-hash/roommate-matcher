package com.nestmates.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class ContactServlet extends HttpServlet {

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String name = trim(request.getParameter("name"));
        String email = trim(request.getParameter("email"));
        String subject = trim(request.getParameter("subject"));
        String message = trim(request.getParameter("message"));

        if (name.isEmpty() || email.isEmpty() || message.isEmpty()) {
            redirectWithError(
                    request,
                    response,
                    "Please fill in all required fields."
            );
            return;
        }

        if (!email.contains("@") || !email.contains(".")) {
            redirectWithError(
                    request,
                    response,
                    "Please enter a valid email address."
            );
            return;
        }

        System.out.println("=== NESTMATES Contact Form ===");
        System.out.println("Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("Subject: " + (subject.isEmpty() ? "General inquiry" : subject));
        System.out.println("Message: " + message);
        System.out.println("==============================");

        String successMessage =
                "Thanks " + name + "! We received your message and will get back to you soon.";

        response.sendRedirect(
                request.getContextPath()
                        + "/contact.jsp?success="
                        + URLEncoder.encode(successMessage, StandardCharsets.UTF_8)
        );
    }

    private String trim(String value) {
        return value == null ? "" : value.trim();
    }

    private void redirectWithError(
            HttpServletRequest request,
            HttpServletResponse response,
            String error)
            throws IOException {

        response.sendRedirect(
                request.getContextPath()
                        + "/contact.jsp?error="
                        + URLEncoder.encode(error, StandardCharsets.UTF_8)
        );
    }
}
