package com.nestmates.controller;

import com.nestmates.dao.ProfileDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Map;
import java.util.UUID;

public class ProfileServlet extends HttpServlet {

    private ProfileDAO profileDAO;

    @Override
    public void init() {
        profileDAO = new ProfileDAO();
    }

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding(StandardCharsets.UTF_8.name());

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        int userId;
        try {
            userId = Integer.parseInt(session.getAttribute("userId").toString());
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String csrfToken = (String) session.getAttribute("csrfToken");
        if (csrfToken == null) {
            csrfToken = UUID.randomUUID().toString();
            session.setAttribute("csrfToken", csrfToken);
        }
        String submittedToken = request.getParameter("csrfToken");
        if (submittedToken == null || !MessageDigest.isEqual(
                csrfToken.getBytes(StandardCharsets.UTF_8),
                submittedToken.getBytes(StandardCharsets.UTF_8))) {
            response.sendRedirect(request.getContextPath()
                    + "/create-profile.jsp?error=Your+page+expired.+Please+try+again");
            return;
        }

        // Form Fields
        String name = request.getParameter("name");
        String bio = request.getParameter("bio");
        String location = request.getParameter("location");
        String ageText = request.getParameter("age");
        String occupation = request.getParameter("occupation");
        String sleepSchedule = request.getParameter("sleepSchedule");
        String cleanliness = request.getParameter("cleanliness");
        String smoking = request.getParameter("smoking");
        String pets = request.getParameter("pets");

        // Extended Form Fields
        String budgetMinText = request.getParameter("budgetMin");
        String budgetMaxText = request.getParameter("budgetMax");
        String gender = request.getParameter("gender");
        String preferredLocation = request.getParameter("preferredLocation");
        String moveInDate = request.getParameter("moveInDate");
        String avatarEmoji = request.getParameter("avatarEmoji");

        if (name == null || name.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/create-profile.jsp?error=Please+enter+your+name");
            return;
        }

        if (ageText == null || ageText.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/create-profile.jsp?error=Please+enter+your+age");
            return;
        }

        int age;
        try {
            age = Integer.parseInt(ageText.trim());
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/create-profile.jsp?error=Please+enter+a+valid+age");
            return;
        }

        if (age < 18 || age > 100) {
            response.sendRedirect(request.getContextPath() + "/create-profile.jsp?error=Age+must+be+between+18+and+100");
            return;
        }

        int budgetMin = 8000;
        int budgetMax = 25000;
        try { if (budgetMinText != null) budgetMin = Integer.parseInt(budgetMinText.trim()); } catch (Exception ignored) {}
        try { if (budgetMaxText != null) budgetMax = Integer.parseInt(budgetMaxText.trim()); } catch (Exception ignored) {}

        if (budgetMin < 1000 || budgetMax < budgetMin || budgetMax > 300000) {
            response.sendRedirect(request.getContextPath()
                    + "/create-profile.jsp?error=Enter+a+valid+monthly+budget+range+in+rupees");
            return;
        }

        boolean saved;
        try {
            saved = profileDAO.saveProfile(
                    userId,
                    name.trim(),
                    bio == null ? "" : bio.trim(),
                    location == null ? "" : location.trim(),
                    age,
                    occupation == null ? "" : occupation.trim(),
                    sleepSchedule == null ? "" : sleepSchedule.trim(),
                    cleanliness == null ? "" : cleanliness.trim(),
                    smoking == null ? "" : smoking.trim(),
                    pets == null ? "" : pets.trim(),
                    budgetMin,
                    budgetMax,
                    gender == null ? "Any" : gender.trim(),
                    preferredLocation == null ? "" : preferredLocation.trim(),
                    moveInDate == null ? "Flexible" : moveInDate.trim(),
                    avatarEmoji == null || avatarEmoji.isBlank() ? "👨🏻" : avatarEmoji.trim()
            );

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/create-profile.jsp?error=Database+error+while+saving+profile");
            return;
        }

        if (saved) {
            response.sendRedirect(request.getContextPath() + "/profile?saved=true");
        } else {
            response.sendRedirect(request.getContextPath() + "/create-profile.jsp?error=Could+not+save+profile");
        }
    }

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        int userId;
        try {
            userId = Integer.parseInt(session.getAttribute("userId").toString());
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        Map<String, Object> profile;
        try {
            profile = profileDAO.getProfile(userId);
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/dashboard?error=Could+not+load+profile");
            return;
        }

        if (profile == null) {
            response.sendRedirect(request.getContextPath() + "/create-profile.jsp?error=Please+create+your+profile+first");
            return;
        }

        request.setAttribute("profile", profile);
        String csrfToken = (String) session.getAttribute("csrfToken");
        if (csrfToken == null) {
            csrfToken = UUID.randomUUID().toString();
            session.setAttribute("csrfToken", csrfToken);
        }
        request.setAttribute("csrfToken", csrfToken);

        request.getRequestDispatcher("/profile.jsp").forward(request, response);
    }
}
