package com.nestmates;

import org.apache.catalina.Context;
import org.apache.catalina.WebResourceRoot;
import org.apache.catalina.connector.Connector;
import org.apache.catalina.startup.Tomcat;
import org.apache.catalina.webresources.DirResourceSet;
import org.apache.catalina.webresources.StandardRoot;

import java.io.File;
import java.net.URISyntaxException;
import java.net.URL;

/**
 * Launches an embedded Tomcat server so the project can be started with:
 *   java -jar build/roommate-matcher-for-friends.war
 *
 * The WAR content (JSPs, assets, WEB-INF) is loaded from the nested
 * webapp directory that the shade plugin bundles inside the JAR.
 */
public final class EmbeddedServer {

    private static final int DEFAULT_PORT = 8080;

    public static void main(String[] args) throws Exception {

        int port = DEFAULT_PORT;
        String portEnv = System.getenv("PORT");
        if (portEnv == null || portEnv.isBlank()) {
            portEnv = System.getProperty("PORT");
        }
        if (portEnv != null && !portEnv.isBlank()) {
            try {
                port = Integer.parseInt(portEnv.trim());
            } catch (NumberFormatException ignored) {
            }
        }
        for (String arg : args) {
            if (arg.startsWith("--port=")) {
                try {
                    port = Integer.parseInt(arg.substring(7));
                } catch (NumberFormatException ignored) {
                }
            }
        }

        // Resolve the webapp directory from the class-path root
        String webappDir = resolveWebappDir();

        Tomcat tomcat = new Tomcat();
        tomcat.setBaseDir(System.getProperty("java.io.tmpdir") + "/roommate-matcher-for-friends-tomcat");

        Connector connector = tomcat.getConnector();
        connector.setPort(port);

        Context ctx = tomcat.addWebapp("", webappDir);
        ctx.setUseHttpOnly(true);
        ctx.setCookieProcessor(new org.apache.tomcat.util.http.Rfc6265CookieProcessor());
        ((org.apache.tomcat.util.http.Rfc6265CookieProcessor) ctx.getCookieProcessor())
                .setSameSiteCookies("lax");

        // Serve compiled servlet classes from the same JAR
        WebResourceRoot resources = new StandardRoot(ctx);
        URL classesUrl = EmbeddedServer.class.getProtectionDomain().getCodeSource().getLocation();
        resources.addPreResources(
                new DirResourceSet(resources, "/WEB-INF/classes",
                        new File(classesUrl.toURI()).getAbsolutePath(), "/"));
        ctx.setResources(resources);

        tomcat.start();

        System.out.println("=================================================");
        System.out.println("  Roommate Matcher running at http://localhost:" + port + "/");
        System.out.println("  Press Ctrl+C to stop.");
        System.out.println("=================================================");

        tomcat.getServer().await();
    }


    /**
     * Returns the absolute path to the webapp directory.
     * When running from the fat-WAR the webapp resources are extracted
     * to a temp directory by Tomcat; when running from the IDE they are
     * found directly under src/main/webapp.
     */
    private static String resolveWebappDir() throws URISyntaxException {
        // Try to find src/main/webapp relative to the executable JAR
        URL jarUrl = EmbeddedServer.class.getProtectionDomain().getCodeSource().getLocation();
        File jar = new File(jarUrl.toURI());

        // Walk up to find the project root (the directory containing pom.xml)
        File candidate = jar.getParentFile();
        for (int i = 0; i < 5; i++) {
            File webapp = new File(candidate, "src/main/webapp");
            if (webapp.exists()) {
                return webapp.getAbsolutePath();
            }
            candidate = candidate.getParentFile();
            if (candidate == null) break;
        }

        // Fallback — serve from the current directory
        File fallback = new File("src/main/webapp");
        if (fallback.exists()) return fallback.getAbsolutePath();

        // Last resort — temp dir (Tomcat will still load classes from the JAR)
        File tmp = new File(System.getProperty("java.io.tmpdir"), "nestmates-webapp");
        tmp.mkdirs();
        return tmp.getAbsolutePath();
    }
}
