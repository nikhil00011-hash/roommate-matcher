package com.nestmates.dao;

import com.nestmates.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

public class RequestDAO {

    public enum SendRequestResult {
        CREATED,
        ALREADY_SENT,
        INCOMING_REQUEST,
        ALREADY_CONNECTED,
        RECEIVER_NOT_FOUND,
        INVALID
    }

    public SendRequestResult sendRequest(
            int senderId,
            int receiverId) {

        if (senderId <= 0 || receiverId <= 0 ||
                senderId == receiverId) {

            return SendRequestResult.INVALID;
        }

        String receiverSql = """
                SELECT 1
                FROM users
                WHERE id = ?
                """;

        String existingRequestSql = """
                SELECT id, sender_id, receiver_id, status
                FROM requests
                WHERE (sender_id = ? AND receiver_id = ?)
                   OR (sender_id = ? AND receiver_id = ?)
                ORDER BY updated_at DESC, id DESC
                """;

        String insertSql = """
                INSERT INTO requests (sender_id, receiver_id, status)
                VALUES (?, ?, 'PENDING')
                """;

        try (Connection connection =
                     DatabaseConnection.getConnection()) {

            try (PreparedStatement receiverStatement =
                         connection.prepareStatement(receiverSql)) {

                receiverStatement.setInt(1, receiverId);

                try (ResultSet receiver =
                             receiverStatement.executeQuery()) {

                    if (!receiver.next()) {
                        return SendRequestResult.RECEIVER_NOT_FOUND;
                    }
                }
            }

            try (PreparedStatement existingStatement =
                         connection.prepareStatement(existingRequestSql)) {

                existingStatement.setInt(1, senderId);
                existingStatement.setInt(2, receiverId);
                existingStatement.setInt(3, receiverId);
                existingStatement.setInt(4, senderId);

                try (ResultSet existing =
                             existingStatement.executeQuery()) {

                    int declinedRequestId = -1;

                    while (existing.next()) {

                        String status = existing.getString("status");
                        int existingId = existing.getInt("id");
                        int existingSender =
                                existing.getInt("sender_id");

                        if ("ACCEPTED".equalsIgnoreCase(status)) {
                            return SendRequestResult.ALREADY_CONNECTED;
                        }

                        if ("PENDING".equalsIgnoreCase(status)) {
                            return existingSender == senderId
                                    ? SendRequestResult.ALREADY_SENT
                                    : SendRequestResult.INCOMING_REQUEST;
                        }

                        if (existingSender == senderId &&
                                "DECLINED".equalsIgnoreCase(status)) {
                            declinedRequestId = existingId;
                        }
                    }

                    if (declinedRequestId > 0) {
                        String reopenSql = """
                                UPDATE requests
                                SET status = 'PENDING'
                                WHERE id = ? AND sender_id = ? AND receiver_id = ?
                                """;

                        try (PreparedStatement reopenStatement =
                                     connection.prepareStatement(reopenSql)) {
                            reopenStatement.setInt(1, declinedRequestId);
                            reopenStatement.setInt(2, senderId);
                            reopenStatement.setInt(3, receiverId);

                            if (reopenStatement.executeUpdate() > 0) {
                                return SendRequestResult.CREATED;
                            }
                        }
                    }
                }
            }

            try (PreparedStatement insertStatement =
                         connection.prepareStatement(insertSql)) {

                insertStatement.setInt(1, senderId);
                insertStatement.setInt(2, receiverId);
                insertStatement.executeUpdate();

                return SendRequestResult.CREATED;
            }

        } catch (Exception e) {

            System.err.println("ERROR creating roommate request");
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    public Map<Integer, String> getSentRequestStatuses(int senderId) {

        String sql = """
                SELECT receiver_id, status
                FROM requests
                WHERE sender_id = ?
                ORDER BY updated_at DESC, id DESC
                """;

        Map<Integer, String> statuses = new HashMap<>();

        try (Connection connection =
                     DatabaseConnection.getConnection();

             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(1, senderId);

            try (ResultSet result = statement.executeQuery()) {

                while (result.next()) {

                    statuses.putIfAbsent(
                            result.getInt("receiver_id"),
                            result.getString("status")
                    );
                }
            }

        } catch (Exception e) {

            System.err.println("ERROR loading sent roommate requests");
            e.printStackTrace();
        }

        return statuses;
    }

    public int countPendingIncoming(int userId) {

        String sql = """
                SELECT COUNT(*)
                FROM requests
                WHERE receiver_id = ?
                  AND status = 'PENDING'
                """;

        try (Connection connection =
                     DatabaseConnection.getConnection();

             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(1, userId);

            try (ResultSet result = statement.executeQuery()) {
                if (result.next()) {
                    return result.getInt(1);
                }
            }

        } catch (Exception e) {
            System.err.println("ERROR counting pending requests");
            e.printStackTrace();
        }

        return 0;
    }

    public java.util.List<Map<String, Object>> getIncomingRequests(int userId) {

        String sql = """
                SELECT
                    r.id,
                    r.sender_id AS other_user_id,
                    r.status,
                    r.created_at,
                    p.name,
                    p.location,
                    p.occupation,
                    p.sleep_schedule,
                    p.age
                FROM requests r
                JOIN profiles p ON p.user_id = r.sender_id
                WHERE r.receiver_id = ?
                ORDER BY r.created_at DESC
                """;

        return loadRequestRows(sql, userId);
    }

    public java.util.List<Map<String, Object>> getSentRequests(int userId) {

        String sql = """
                SELECT
                    r.id,
                    r.receiver_id AS other_user_id,
                    r.status,
                    r.created_at,
                    p.name,
                    p.location,
                    p.occupation,
                    p.sleep_schedule,
                    p.age
                FROM requests r
                JOIN profiles p ON p.user_id = r.receiver_id
                WHERE r.sender_id = ?
                ORDER BY r.created_at DESC
                """;

        return loadRequestRows(sql, userId);
    }

    private java.util.List<Map<String, Object>> loadRequestRows(
            String sql,
            int userId) {

        java.util.List<Map<String, Object>> requests =
                new java.util.ArrayList<>();

        try (Connection connection =
                     DatabaseConnection.getConnection();

             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(1, userId);

            try (ResultSet result = statement.executeQuery()) {

                while (result.next()) {

                    Map<String, Object> row = new HashMap<>();

                    row.put("id", result.getInt("id"));
                    row.put("otherUserId", result.getInt("other_user_id"));
                    row.put("status", result.getString("status"));
                    row.put("createdAt", result.getTimestamp("created_at"));
                    row.put("name", result.getString("name"));
                    row.put("location", result.getString("location"));
                    row.put("occupation", result.getString("occupation"));
                    row.put("sleepSchedule", result.getString("sleep_schedule"));
                    row.put("age", result.getInt("age"));

                    requests.add(row);
                }
            }

        } catch (Exception e) {
            System.err.println("ERROR loading roommate requests");
            e.printStackTrace();
        }

        return requests;
    }

    public boolean updateRequestStatus(
            int requestId,
            int userId,
            String newStatus) {

        String sql = """
                UPDATE requests
                SET status = ?
                WHERE id = ?
                  AND receiver_id = ?
                  AND status = 'PENDING'
                """;

        try (Connection connection =
                     DatabaseConnection.getConnection();

             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setString(1, newStatus);
            statement.setInt(2, requestId);
            statement.setInt(3, userId);

            return statement.executeUpdate() > 0;

        } catch (Exception e) {
            System.err.println("ERROR updating roommate request");
            e.printStackTrace();
            return false;
        }
    }
}
