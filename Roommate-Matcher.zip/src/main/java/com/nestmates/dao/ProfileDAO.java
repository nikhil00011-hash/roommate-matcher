package com.nestmates.dao;

import com.nestmates.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProfileDAO {

    // =========================================================
    // SAVE OR UPDATE PROFILE (EXTENDED)
    // =========================================================

    public boolean saveProfile(
            int userId,
            String name,
            String bio,
            String location,
            int age,
            String occupation,
            String sleepSchedule,
            String cleanlinessLevel,
            String smoking,
            String pets,
            int budgetMin,
            int budgetMax,
            String gender,
            String preferredLocation,
            String moveInDate,
            String avatarEmoji) {

        String sql = """
                INSERT INTO profiles
                (
                    user_id,
                    name,
                    bio,
                    location,
                    age,
                    occupation,
                    sleep_schedule,
                    cleanliness_level,
                    smoking,
                    pets,
                    budget_min,
                    budget_max,
                    gender,
                    preferred_location,
                    move_in_date,
                    avatar_emoji
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)

                ON DUPLICATE KEY UPDATE
                    name = VALUES(name),
                    bio = VALUES(bio),
                    location = VALUES(location),
                    age = VALUES(age),
                    occupation = VALUES(occupation),
                    sleep_schedule = VALUES(sleep_schedule),
                    cleanliness_level = VALUES(cleanliness_level),
                    smoking = VALUES(smoking),
                    pets = VALUES(pets),
                    budget_min = VALUES(budget_min),
                    budget_max = VALUES(budget_max),
                    gender = VALUES(gender),
                    preferred_location = VALUES(preferred_location),
                    move_in_date = VALUES(move_in_date),
                    avatar_emoji = VALUES(avatar_emoji)
                """;

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)
        ) {

            statement.setInt(1, userId);
            statement.setString(2, name);
            statement.setString(3, bio);
            statement.setString(4, location);
            statement.setInt(5, age);
            statement.setString(6, occupation);
            statement.setString(7, sleepSchedule);
            statement.setString(8, cleanlinessLevel);
            statement.setString(9, smoking);
            statement.setString(10, pets);
            statement.setInt(11, budgetMin > 0 ? budgetMin : 8000);
            statement.setInt(12, budgetMax > 0 ? budgetMax : 25000);
            statement.setString(13, gender != null ? gender : "Any");
            statement.setString(14, preferredLocation != null ? preferredLocation : location);
            statement.setString(15, moveInDate != null ? moveInDate : "Flexible");
            statement.setString(16, avatarEmoji != null && !avatarEmoji.isBlank() ? avatarEmoji : "👨🏻");

            return statement.executeUpdate() > 0;

        } catch (Exception e) {
            System.err.println("ERROR saving extended profile for userId: " + userId);
            e.printStackTrace();
            return false;
        }
    }

    public boolean saveProfile(
            int userId,
            String name,
            String bio,
            String location,
            int age,
            String occupation,
            String sleepSchedule,
            String cleanlinessLevel,
            String smoking,
            String pets) {
        return saveProfile(userId, name, bio, location, age, occupation, sleepSchedule, cleanlinessLevel, smoking, pets, 8000, 25000, "Any", location, "Flexible", "👨🏻");
    }

    // =========================================================
    // GET PROFILE BY USER ID
    // =========================================================

    public Map<String, Object> getProfile(int userId) {

        String sql = """
                SELECT
                    id,
                    user_id,
                    name,
                    bio,
                    location,
                    age,
                    occupation,
                    sleep_schedule,
                    cleanliness_level,
                    smoking,
                    pets,
                    budget_min,
                    budget_max,
                    gender,
                    preferred_location,
                    move_in_date,
                    avatar_emoji
                FROM profiles
                WHERE user_id = ?
                """;

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)
        ) {

            statement.setInt(1, userId);

            try (ResultSet result = statement.executeQuery()) {
                if (result.next()) {
                    return mapProfileRow(result);
                }
            }

        } catch (Exception e) {
            System.err.println("ERROR loading profile for userId: " + userId);
            e.printStackTrace();
        }

        return null;
    }

    // =========================================================
    // GET OTHER USER PROFILES
    // =========================================================

    public List<Map<String, Object>> getOtherProfiles(int currentUserId) {

        String sql = """
                SELECT
                    id,
                    user_id,
                    name,
                    bio,
                    location,
                    age,
                    occupation,
                    sleep_schedule,
                    cleanliness_level,
                    smoking,
                    pets,
                    budget_min,
                    budget_max,
                    gender,
                    preferred_location,
                    move_in_date,
                    avatar_emoji
                FROM profiles
                WHERE user_id <> ?
                ORDER BY id DESC
                """;

        List<Map<String, Object>> profiles = new ArrayList<>();

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)
        ) {

            statement.setInt(1, currentUserId);

            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    profiles.add(mapProfileRow(result));
                }
            }

        } catch (Exception e) {
            System.err.println("ERROR loading roommate profiles");
            e.printStackTrace();
        }

        return profiles;
    }

    private Map<String, Object> mapProfileRow(ResultSet result) throws Exception {
        Map<String, Object> profile = new HashMap<>();

        profile.put("id", result.getInt("id"));
        profile.put("userId", result.getInt("user_id"));
        profile.put("name", result.getString("name"));
        profile.put("bio", result.getString("bio"));
        profile.put("location", result.getString("location"));
        profile.put("age", result.getInt("age"));
        profile.put("occupation", result.getString("occupation"));
        profile.put("sleepSchedule", result.getString("sleep_schedule"));
        profile.put("cleanliness", result.getString("cleanliness_level"));
        profile.put("smoking", result.getString("smoking"));
        profile.put("pets", result.getString("pets"));
        
        // Extended attributes
        try { profile.put("budgetMin", result.getInt("budget_min")); } catch (Exception ignored) { profile.put("budgetMin", 8000); }
        try { profile.put("budgetMax", result.getInt("budget_max")); } catch (Exception ignored) { profile.put("budgetMax", 25000); }
        try { profile.put("gender", result.getString("gender")); } catch (Exception ignored) { profile.put("gender", "Any"); }
        try { profile.put("preferredLocation", result.getString("preferred_location")); } catch (Exception ignored) { profile.put("preferredLocation", "Any"); }
        try { profile.put("moveInDate", result.getString("move_in_date")); } catch (Exception ignored) { profile.put("moveInDate", "Flexible"); }
        try { profile.put("avatarEmoji", result.getString("avatar_emoji")); } catch (Exception ignored) { profile.put("avatarEmoji", "👨🏻"); }

        return profile;
    }
}
