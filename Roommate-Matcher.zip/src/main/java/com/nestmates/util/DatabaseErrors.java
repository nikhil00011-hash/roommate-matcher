package com.nestmates.util;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;

public final class DatabaseErrors {
    private DatabaseErrors() {
    }

    /** User-facing message when JDBC fails (Tomcat often missing NESTMATES_DB_*). */
    public static String signInMessage(SQLException exception) {
        String detail = exception != null ? exception.getMessage() : null;
        if (detail != null && detail.contains("NESTMATES_DB_PASSWORD")) {
            return "Set NESTMATES_DB_PASSWORD in the environment before starting the app, then try again.";
        }
        return "Cannot connect to MySQL. Make sure the database is running and NESTMATES_DB_URL, NESTMATES_DB_USER, and NESTMATES_DB_PASSWORD are configured.";
    }

    public static String urlEncodedSignInMessage(SQLException exception) {
        return URLEncoder.encode(signInMessage(exception), StandardCharsets.UTF_8);
    }
}
