package com.nestmates.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class DatabaseConnection {
    private DatabaseConnection() {
    }

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException exception) {
            throw new ExceptionInInitializerError(exception);
        }
    }

    public static Connection getConnection() throws SQLException {
        String url = setting("NESTMATES_DB_URL", "jdbc:mysql://localhost:3306/nestmates?useSSL=false&serverTimezone=Asia/Kolkata&allowPublicKeyRetrieval=true");
        String user = setting("NESTMATES_DB_USER", "nestmates_app");
        String password = setting("NESTMATES_DB_PASSWORD", null);
        if (password == null) {
            throw new SQLException("Set NESTMATES_DB_PASSWORD before starting Tomcat.");
        }
        return DriverManager.getConnection(url, user, password);
    }

    private static String setting(String name, String fallback) {
        String value = System.getenv(name);
        if (value == null || value.isBlank()) value = System.getProperty(name);
        return value == null || value.isBlank() ? fallback : value;
    }
}
