package com.nestmates.util;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.security.MessageDigest;
import java.util.UUID;

/**
 * Centralises the session and CSRF rules used by the JSP endpoints.
 */
public final class SecurityUtil {
    public static final String USER_ID = "userId";
    public static final String CSRF_TOKEN = "csrfToken";
    private static final int SESSION_TIMEOUT_SECONDS = 30 * 60;

    private SecurityUtil() {}

    public static Integer currentUserId(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) return null;
        Object value = session.getAttribute(USER_ID);
        if (value instanceof Integer id && id > 0) return id;
        if (value instanceof String text) {
            try {
                int id = Integer.parseInt(text);
                return id > 0 ? id : null;
            } catch (NumberFormatException ignored) {
                return null;
            }
        }
        return null;
    }

    public static HttpSession startSession(HttpServletRequest request, int userId, String email) {
        HttpSession old = request.getSession(false);
        if (old != null) old.invalidate();
        HttpSession session = request.getSession(true);
        session.setAttribute(USER_ID, userId);
        session.setAttribute("email", email);
        session.setAttribute(CSRF_TOKEN, UUID.randomUUID().toString());
        session.setMaxInactiveInterval(SESSION_TIMEOUT_SECONDS);
        return session;
    }

    public static String csrfToken(HttpSession session) {
        Object existing = session.getAttribute(CSRF_TOKEN);
        if (existing instanceof String token && !token.isBlank()) return token;
        String token = UUID.randomUUID().toString();
        session.setAttribute(CSRF_TOKEN, token);
        return token;
    }

    public static boolean validCsrf(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) return false;
        Object expected = session.getAttribute(CSRF_TOKEN);
        String supplied = request.getParameter(CSRF_TOKEN);
        return expected instanceof String && supplied != null
                && MessageDigest.isEqual(((String) expected).getBytes(java.nio.charset.StandardCharsets.UTF_8),
                supplied.getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }

    public static boolean requireCsrf(HttpServletRequest request, HttpServletResponse response)
            throws java.io.IOException {
        if (validCsrf(request)) return true;
        response.sendError(HttpServletResponse.SC_FORBIDDEN, "Invalid CSRF token");
        return false;
    }

    public static void securityHeaders(HttpServletResponse response) {
        response.setHeader("X-Content-Type-Options", "nosniff");
        response.setHeader("X-Frame-Options", "SAMEORIGIN");
        response.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
        response.setHeader("Cache-Control", "no-store");
    }
}
