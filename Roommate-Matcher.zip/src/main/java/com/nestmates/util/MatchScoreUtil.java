package com.nestmates.util;

import java.util.Map;

public final class MatchScoreUtil {

    private MatchScoreUtil() {
    }

    public static int calculateMatchScore(
            Map<String, Object> currentProfile,
            Map<String, Object> otherProfile) {

        if (currentProfile == null || otherProfile == null) {
            return 0;
        }

        double score = 0.0;

        // 1. LIFESTYLE HABITS ALIGNMENT (50% max)
        if (sameValue(currentProfile.get("sleepSchedule"), otherProfile.get("sleepSchedule"))) {
            score += 12.5;
        }

        if (sameValue(currentProfile.get("cleanliness"), otherProfile.get("cleanliness"))) {
            score += 12.5;
        }

        if (sameValue(currentProfile.get("smoking"), otherProfile.get("smoking"))) {
            score += 12.5;
        }

        if (sameValue(currentProfile.get("pets"), otherProfile.get("pets"))) {
            score += 12.5;
        }

        // 2. BUDGET RANGE COMPATIBILITY (30% max)
        int currentMin = getIntVal(currentProfile.get("budgetMin"), 8000);
        int currentMax = getIntVal(currentProfile.get("budgetMax"), 25000);
        int otherMin = getIntVal(otherProfile.get("budgetMin"), 8000);
        int otherMax = getIntVal(otherProfile.get("budgetMax"), 25000);

        int overlapMin = Math.max(currentMin, otherMin);
        int overlapMax = Math.min(currentMax, otherMax);

        if (overlapMin <= overlapMax) {
            // Overlapping budgets
            score += 30.0;
        } else {
            // Close budget check (within ₹2,000 tolerance)
            int gap = overlapMin - overlapMax;
            if (gap <= 2000) {
                score += 15.0;
            }
        }

        // 3. LOCATION & PROFILE COMPLETENESS (20% max)
        String currentLoc = getStringVal(currentProfile.get("location"));
        String otherLoc = getStringVal(otherProfile.get("location"));
        String preferredLoc = getStringVal(currentProfile.get("preferredLocation"));

        if (!currentLoc.isEmpty() && (currentLoc.equalsIgnoreCase(otherLoc) || currentLoc.equalsIgnoreCase(preferredLoc))) {
            score += 10.0;
        }

        int otherCompleteness = profileProgress(otherProfile);
        if (otherCompleteness >= 75) {
            score += 10.0;
        } else if (otherCompleteness >= 50) {
            score += 5.0;
        }

        return (int) Math.min(Math.round(score), 100);
    }

    public static int profileProgress(Map<String, Object> profile) {

        if (profile == null) {
            return 0;
        }

        String[] fields = {
                "name",
                "bio",
                "location",
                "occupation",
                "sleepSchedule",
                "cleanliness",
                "smoking",
                "pets",
                "preferredLocation",
                "moveInDate"
        };

        int filled = 0;

        for (String field : fields) {
            Object value = profile.get(field);

            if (value != null) {
                String text = value.toString().trim();

                if (!text.isEmpty() && !text.equalsIgnoreCase("null")) {
                    filled++;
                }
            }
        }

        if (getIntVal(profile.get("age"), 0) > 0) {
            filled++;
        }

        if (getIntVal(profile.get("budgetMax"), 0) > 0) {
            filled++;
        }

        return Math.round((filled * 100f) / (fields.length + 2));
    }

    private static boolean sameValue(Object first, Object second) {

        if (first == null || second == null) {
            return false;
        }

        String firstValue = first.toString().trim();
        String secondValue = second.toString().trim();

        if (firstValue.isEmpty() ||
                secondValue.isEmpty() ||
                firstValue.equalsIgnoreCase("null") ||
                secondValue.equalsIgnoreCase("null")) {

            return false;
        }

        return firstValue.equalsIgnoreCase(secondValue);
    }

    private static int getIntVal(Object obj, int fallback) {
        if (obj instanceof Number number) {
            return number.intValue();
        }
        if (obj != null) {
            try {
                return Integer.parseInt(obj.toString().trim());
            } catch (NumberFormatException ignored) {
            }
        }
        return fallback;
    }

    private static String getStringVal(Object obj) {
        if (obj == null) return "";
        String text = obj.toString().trim();
        return text.equalsIgnoreCase("null") ? "" : text;
    }
}
