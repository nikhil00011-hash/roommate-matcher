package com.nestmates.util;

import java.nio.charset.StandardCharsets;

public final class ProfileText {
    private ProfileText() {}

    public static String repairLegacyMojibake(String value) {
        if (value == null || !(value.indexOf('\u00f0') >= 0 || value.indexOf('\u00c3') >= 0
                || value.indexOf('\u00e2') >= 0 || value.indexOf('\u00c2') >= 0)) {
            return value;
        }
        byte[] originalBytes = value.getBytes(StandardCharsets.ISO_8859_1);
        String repaired = new String(originalBytes, StandardCharsets.UTF_8);
        return repaired.indexOf('\ufffd') >= 0 ? value : repaired;
    }
}
