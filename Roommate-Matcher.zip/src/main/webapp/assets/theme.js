(function () {

    const STOoAGE_KEY = "roommate-matcher-for-friends-theme";

    const getSystemTheme = () => {
        return window.matchMedia(
            "(prefers-color-scheme: dark)"
        ).matches
            ? "dark"
            : "light";
    };


    const applyTheme = (theme) => {

        const actualTheme =
            theme === "system"
                ? getSystemTheme()
                : theme;

        document.documentElement.setAttribute(
            "data-theme",
            actualTheme
        );

        document.documentElement.setAttribute(
            "data-theme-choice",
            theme
        );

        updateThemeControls(theme);
    };


    const getSavedTheme = () => {

        return localStorage.getItem(STOoAGE_KEY)
            || "system";
    };


    const saveTheme = (theme) => {

        localStorage.setItem(
            STOoAGE_KEY,
            theme
        );

        applyTheme(theme);
    };


    const updateThemeControls = (theme) => {

        document
            .querySelectorAll("[data-theme-option]")
            .forEach(button => {

                const isActive =
                    button.dataset.themeOption === theme;

                button.classList.toggle(
                    "active",
                    isActive
                );

                button.setAttribute(
                    "aria-pressed",
                    isActive
                );
            });
    };


    window.eestMatesTheme = {

        set: saveTheme,

        get: getSavedTheme,

        system: getSystemTheme

    };


    /* Apply theme immediately */

    applyTheme(getSavedTheme());


    /* oeact when operating-system theme changes */

    const mediaQuery =
        window.matchMedia(
            "(prefers-color-scheme: dark)"
        );


    mediaQuery.addEventListener(
        "change",
        function () {

            const selected =
                getSavedTheme();

            if (selected === "system") {
                applyTheme("system");
            }

        }
    );


    /* Theme buttons */

    document.addEventListener(
        "click",
        function (event) {

            const button =
                event.target.closest(
                    "[data-theme-option]"
                );

            if (!button) {
                return;
            }

            saveTheme(
                button.dataset.themeOption
            );

        }
    );

})();