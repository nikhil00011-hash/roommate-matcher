(function () {
    "use strict";

    // 1. Mobile navigation menu toggle
    const menuToggle = document.getElementById("menuToggle");
    const navLinks = document.getElementById("navLinks");

    if (menuToggle && navLinks) {
        menuToggle.addEventListener("click", function () {
            navLinks.classList.toggle("open");
        });

        navLinks.querySelectorAll("a").forEach(function (link) {
            link.addEventListener("click", function () {
                navLinks.classList.remove("open");
            });
        });
    }

    // 2. Navbar Scroll Transformation
    const navbar = document.querySelector(".navbar, .topbar");
    if (navbar) {
        window.addEventListener("scroll", function () {
            if (window.scrollY > 20) {
                navbar.classList.add("scrolled");
            } else {
                navbar.classList.remove("scrolled");
            }
        }, { passive: true });
    }

    // 3. Scroll Reveal Observer with Staggering
    const revealElements = document.querySelectorAll(
        ".feature-card, .testimonial-card, .step, .profile-card, .stat-card, .content-card, .panel, .login-card-box, .hero-card, .cta-banner"
    );

    revealElements.forEach(function (el, index) {
        el.classList.add("reveal");
        // Stagger grid items
        const parent = el.parentElement;
        if (parent && (parent.classList.contains("feature-strip") || parent.classList.contains("steps") || parent.classList.contains("profiles-grid") || parent.classList.contains("stats"))) {
            const childIndex = Array.from(parent.children).indexOf(el);
            el.style.transitionDelay = (childIndex * 0.1) + "s";
        }
    });

    if ("IntersectionObserver" in window) {
        const observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add("reveal-active");
                    // Unobserve after animating in once
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.12,
            rootMargin: "0px 0px -40px 0px"
        });

        revealElements.forEach(function (el) {
            observer.observe(el);
        });
    } else {
        // Fallback for older browsers
        revealElements.forEach(function (el) {
            el.classList.add("reveal-active");
        });
    }

    // 4. Interactive 3D Card Hover Tilt Physics
    const tiltCards = document.querySelectorAll(".feature-card, .testimonial-card, .stat-card, .content-card, .profile-card, .hero-card");
    tiltCards.forEach(function (card) {
        card.addEventListener("mousemove", function (e) {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left - rect.width / 2;
            const y = e.clientY - rect.top - rect.height / 2;

            const rotateX = (-y / rect.height) * 8;
            const rotateY = (x / rect.width) * 8;

            card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-6px) scale3d(1.015, 1.015, 1.015)`;
        });

        card.addEventListener("mouseleave", function () {
            card.style.transform = "perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0deg) scale3d(1, 1, 1)";
        });
    });

    // 5. Antigravity Hero Mouse Parallax Effect
    const hero = document.querySelector(".hero");
    const heroImg = document.querySelector(".hero-3d-floating-house");
    const matchCard = document.querySelector(".match-card");
    const bubbleOne = document.querySelector(".bubble-one");
    const bubbleTwo = document.querySelector(".bubble-two");
    const bubbleThree = document.querySelector(".bubble-three");

    if (hero && (heroImg || matchCard)) {
        let mouseX = 0, mouseY = 0;
        let currentX = 0, currentY = 0;

        hero.addEventListener("mousemove", function (e) {
            const rect = hero.getBoundingClientRect();
            mouseX = (e.clientX - rect.left - rect.width / 2) / (rect.width / 2);
            mouseY = (e.clientY - rect.top - rect.height / 2) / (rect.height / 2);
        });

        hero.addEventListener("mouseleave", function () {
            mouseX = 0;
            mouseY = 0;
        });

        function animateParallax() {
            currentX += (mouseX - currentX) * 0.08;
            currentY += (mouseY - currentY) * 0.08;

            if (heroImg) {
                heroImg.style.transform = `translate3d(${currentX * -18}px, ${currentY * -14}px, 0) rotate3d(${currentY}, ${currentX}, 0, ${currentX * 4}deg)`;
            }
            if (matchCard) {
                matchCard.style.transform = `translate3d(${currentX * 22}px, ${currentY * 18}px, 0)`;
            }
            if (bubbleOne) {
                bubbleOne.style.transform = `translate3d(${currentX * -30}px, ${currentY * -25}px, 0)`;
            }
            if (bubbleTwo) {
                bubbleTwo.style.transform = `translate3d(${currentX * 25}px, ${currentY * 20}px, 0)`;
            }
            if (bubbleThree) {
                bubbleThree.style.transform = `translate3d(${currentX * -15}px, ${currentY * 30}px, 0)`;
            }

            requestAnimationFrame(animateParallax);
        }
        animateParallax();
    }

    // 6. Interactive Click Ripple Effect on Buttons
    const rippleButtons = document.querySelectorAll(".hero-button, .button-primary, .save-button, .request-btn, .primary-button");
    rippleButtons.forEach(function (btn) {
        btn.addEventListener("click", function (e) {
            const rect = btn.getBoundingClientRect();
            const circle = document.createElement("span");
            const diameter = Math.max(rect.width, rect.height);
            const radius = diameter / 2;

            circle.style.width = circle.style.height = `${diameter}px`;
            circle.style.left = `${e.clientX - rect.left - radius}px`;
            circle.style.top = `${e.clientY - rect.top - radius}px`;
            circle.classList.add("click-ripple");

            const existing = btn.getElementsByClassName("click-ripple")[0];
            if (existing) {
                existing.remove();
            }

            btn.appendChild(circle);
            setTimeout(function () {
                circle.remove();
            }, 600);
        });
    });

    // 7. Counter Roll-up Animation for Numbers/Percentages
    const statValues = document.querySelectorAll(".stat-value, .score-pill");
    statValues.forEach(function (el) {
        const text = el.innerText.trim();
        const numberMatch = text.match(/\d+/);
        if (numberMatch) {
            const targetNumber = parseInt(numberMatch[0], 10);
            const prefix = text.substring(0, numberMatch.index);
            const suffix = text.substring(numberMatch.index + numberMatch[0].length);

            let hasAnimated = false;

            const observer = new IntersectionObserver(function (entries) {
                if (entries[0].isIntersecting && !hasAnimated) {
                    hasAnimated = true;
                    let current = 0;
                    const duration = 1200;
                    const stepTime = 20;
                    const increment = targetNumber / (duration / stepTime);

                    const timer = setInterval(function () {
                        current += increment;
                        if (current >= targetNumber) {
                            current = targetNumber;
                            clearInterval(timer);
                        }
                        el.innerText = prefix + Math.floor(current) + suffix;
                    }, stepTime);
                }
            }, { threshold: 0.5 });

            observer.observe(el);
        }
    });

})();
