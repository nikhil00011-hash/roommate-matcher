<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="com.nestmates.util.HtmlUtil" %>

<%@ page import="java.util.List,java.util.Map" %>
<%
    if (session.getAttribute("userId") == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
    List<Map<String, Object>> incoming = (List<Map<String, Object>>) request.getAttribute("incomingRequests");
    List<Map<String, Object>> sent = (List<Map<String, Object>>) request.getAttribute("sentRequests");
    String csrfToken = (String) request.getAttribute("csrfToken");
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Roommate Matcher | Roommate Requests</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --bg: #FFF7EF; --text: #29231F; --muted: #756E68;
            --glass: rgba(255,255,255,.55); --glass-strong: rgba(255,255,255,.78);
            --border: rgba(255,255,255,.85); --coral: #FF8A65; --coral-dark: #F47B57;
            --peach: #FFD9C7; --blue: #B9DDF3; --green: #CDE7D5;
            --shadow: 0 24px 70px rgba(75,55,40,.10);
        }
        body {
            min-height: 100vh; font-family: Inter, "Segoe UI", Arial, sans-serif;
            color: var(--text); background: radial-gradient(circle at 8% 8%, rgba(255,217,199,.46), transparent 24%), var(--bg);
        }
        a { text-decoration: none; color: inherit; }
        .topbar {
            position: fixed; top: 18px; left: 50%; transform: translateX(-50%);
            width: min(1180px, calc(100% - 30px)); display: flex; align-items: center; justify-content: space-between;
            padding: 10px 16px; background: var(--glass); backdrop-filter: blur(22px);
            border: 1px solid var(--border); border-radius: 20px; box-shadow: var(--shadow); z-index: 100;
        }
        .brand { display: flex; align-items: center; gap: 9px; font-size: 19px; font-weight: 900; }
        .brand-icon { width: 36px; height: 36px; display: grid; place-items: center; border-radius: 12px; background: linear-gradient(145deg, #FFD5C0, #FF9A78); }
        .page { width: min(1000px, calc(100% - 30px)); margin: auto; padding: 115px 0 60px; }
        .heading h1 { font-size: clamp(36px, 4vw, 52px); letter-spacing: -2px; }
        .heading p { color: var(--muted); font-size: 14px; margin-top: 8px; }
        .panel { margin-top: 24px; padding: 26px; border-radius: 24px; background: var(--glass-strong); backdrop-filter: blur(24px); border: 1px solid var(--border); box-shadow: var(--shadow); }
        .panel h2 { font-size: 20px; margin-bottom: 16px; font-weight: 800; }
        .request-card {
            display: flex; align-items: center; justify-content: space-between; gap: 16px;
            padding: 16px; margin-bottom: 12px; border-radius: 18px; background: rgba(255,255,255,.6);
            border: 1px solid var(--border);
        }
        .user-info { display: flex; align-items: center; gap: 14px; }
        .avatar { width: 46px; height: 46px; display: grid; place-items: center; border-radius: 16px; background: var(--peach); font-size: 22px; }
        .details strong { font-size: 15px; display: block; }
        .details span { color: var(--muted); font-size: 12px; }
        .status-badge { padding: 6px 12px; border-radius: 50px; font-size: 11px; font-weight: 900; }
        .status-badge.pending { background: #FFE8DF; color: #D8562B; }
        .status-badge.accepted { background: #D1F2D9; color: #1E6B34; }
        .status-badge.declined { background: #F5D3D3; color: #9A2A2A; }
        .action-btns { display: flex; gap: 8px; }
        .accept-btn { padding: 9px 15px; border-radius: 12px; border: none; background: #27643B; color: white; font-weight: 800; font-size: 11px; cursor: pointer; }
        .decline-btn { padding: 9px 15px; border-radius: 12px; border: 1px solid #A3422B; background: transparent; color: #A3422B; font-weight: 800; font-size: 11px; cursor: pointer; }
    </style>
</head>
<body>
<header class="topbar">
    <a class="brand" href="${pageContext.request.contextPath}/dashboard">
        <span class="brand-icon">🏠</span> Roommate Matcher
    </a>
    <a href="${pageContext.request.contextPath}/dashboard" style="font-weight:800;font-size:12px;">← Back to Dashboard</a>
</header>

<main class="page">
    <section class="heading">
        <span style="font-weight:900;font-size:11px;color:var(--coral-dark);">ROOMMATE CONNECTIONS</span>
        <h1>Roommate Requests</h1>
        <p>Review incoming invitations and keep track of sent connection requests.</p>
    </section>

    <section class="panel">
        <h2>Incoming Roommate Requests</h2>
        <% if (incoming == null || incoming.isEmpty()) { %>
            <p style="color:var(--muted);font-size:13px;">No incoming requests yet. When candidates express interest in sharing an apartment, they will appear here!</p>
        <% } else { for (Map<String, Object> row : incoming) { 
            String status = String.valueOf(row.get("status"));
        %>
            <div class="request-card">
                <div class="user-info">
                    <div class="avatar">👤</div>
                    <div class="details">
                        <strong><%= com.nestmates.util.HtmlUtil.escape(row.get("name")) %></strong>
                        <span>📍 <%= com.nestmates.util.HtmlUtil.escape(row.get("location")) %> &nbsp;·&nbsp; <%= com.nestmates.util.HtmlUtil.escape(row.get("occupation")) %></span>
                    </div>
                </div>

                <div>
                    <% if ("PENDING".equalsIgnoreCase(status)) { %>
                        <form method="post" action="${pageContext.request.contextPath}/handle-request" style="display:flex;gap:8px;">
                            <input type="hidden" name="csrfToken" value="<%= com.nestmates.util.HtmlUtil.escape(csrfToken) %>">
                            <input type="hidden" name="requestId" value="<%= com.nestmates.util.HtmlUtil.escape(row.get("id")) %>">
                            <button name="action" value="accept" type="submit" class="accept-btn">Accept Connection ✓</button>
                            <button name="action" value="decline" type="submit" class="decline-btn">Decline</button>
                        </form>
                    <% } else { %>
                        <span class="status-badge <%= com.nestmates.util.HtmlUtil.escape(status.toLowerCase()) %>"><%= com.nestmates.util.HtmlUtil.escape(status) %></span>
                    <% } %>
                </div>
            </div>
        <% } } %>
    </section>

    <section class="panel">
        <h2>Sent Requests</h2>
        <% if (sent == null || sent.isEmpty()) { %>
            <p style="color:var(--muted);font-size:13px;">No sent requests yet. Browse the roommate directory to send your first request!</p>
        <% } else { for (Map<String, Object> row : sent) { 
            String status = String.valueOf(row.get("status"));
        %>
            <div class="request-card">
                <div class="user-info">
                    <div class="avatar">👤</div>
                    <div class="details">
                        <strong><%= com.nestmates.util.HtmlUtil.escape(row.get("name")) %></strong>
                        <span>📍 <%= com.nestmates.util.HtmlUtil.escape(row.get("location")) %> &nbsp;·&nbsp; <%= com.nestmates.util.HtmlUtil.escape(row.get("occupation")) %></span>
                    </div>
                </div>
                <span class="status-badge <%= com.nestmates.util.HtmlUtil.escape(status.toLowerCase()) %>"><%= com.nestmates.util.HtmlUtil.escape(status) %></span>
            </div>
        <% } } %>
    </section>
</main>
</body>
</html>
