<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="com.nestmates.util.HtmlUtil" %>


<%
    if (session.getAttribute("userId") == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }

    String email = (String) session.getAttribute("email");
    if (email == null) email = "user@campus.edu";
    String username = email.contains("@") ? email.substring(0, email.indexOf("@")) : email;

    int profileProgress = request.getAttribute("profileProgress") != null ? (Integer) request.getAttribute("profileProgress") : 0;
    int matchCount = request.getAttribute("matchCount") != null ? (Integer) request.getAttribute("matchCount") : 0;
    int pendingRequests = request.getAttribute("pendingRequests") != null ? (Integer) request.getAttribute("pendingRequests") : 0;
    int topMatchScore = request.getAttribute("topMatchScore") != null ? (Integer) request.getAttribute("topMatchScore") : 0;
    String csrfToken = (String) request.getAttribute("csrfToken");
    
    java.util.Map<String, Object> topMatch = (java.util.Map<String, Object>) request.getAttribute("topMatch");
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roommate Matcher | User Dashboard</title>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        :root {
            --bg: #F7F1E9;
            --glass: rgba(255, 255, 255, 0.55);
            --glass-strong: rgba(255, 255, 255, 0.78);
            --border: rgba(255, 255, 255, 0.85);
            --coral: #FF8A65;
            --coral-dark: #F16F4B;
            --blue: #B9DDF3;
            --peach: #FFD9C7;
            --yellow: #F6E2B1;
            --green: #CDE7D5;
            --text: #29231F;
            --muted: #756E68;
        }

        body {
            min-height: 100vh;
            font-family: Inter, "Segoe UI", Arial, sans-serif;
            color: var(--text);
            background:
                radial-gradient(circle at 5% 8%, rgba(255, 217, 199, .48), transparent 23%),
                radial-gradient(circle at 95% 8%, rgba(185, 221, 243, .52), transparent 24%),
                var(--bg);
            overflow-x: hidden;
        }

        a { text-decoration: none; color: inherit; }

        .sidebar {
            position: fixed; left: 18px; top: 18px; bottom: 18px; width: 245px;
            display: flex; flex-direction: column; padding: 22px 16px;
            background: rgba(255,255,255,.45); backdrop-filter: blur(24px);
            border: 1px solid var(--border); border-radius: 26px;
            box-shadow: 0 25px 70px rgba(80,55,40,.10); z-index: 10;
        }

        .brand { display: flex; align-items: center; gap: 10px; padding: 4px 10px 25px; font-size: 21px; font-weight: 900; }
        .brand-icon { width: 39px; height: 39px; display: grid; place-items: center; border-radius: 13px; background: linear-gradient(145deg, #ffd5c0, #ff9a78); }

        .menu-title { padding: 5px 11px 9px; color: #9a9189; font-size: 10px; font-weight: 900; letter-spacing: 1px; text-transform: uppercase; }
        .menu { display: flex; flex-direction: column; gap: 6px; }

        .menu a {
            display: flex; align-items: center; gap: 12px; padding: 12px 13px;
            border-radius: 14px; color: #5f5751; font-size: 13px; font-weight: 750; transition: .2s;
        }

        .menu a:hover, .menu a.active {
            background: rgba(255,255,255,.8); color: var(--coral-dark); box-shadow: 0 8px 20px rgba(87,62,45,.06);
        }

        .badge-count { margin-left: auto; background: var(--coral); color: white; padding: 2px 8px; border-radius: 50px; font-size: 10px; font-weight: 900; }

        .main { margin-left: 285px; padding: 30px 30px 55px; }

        .topbar { display: flex; align-items: center; justify-content: space-between; margin-bottom: 25px; }
        .topbar-left p { color: var(--muted); font-size: 12px; margin-bottom: 5px; }
        .topbar-left h1 { font-size: 30px; letter-spacing: -1px; font-weight: 900; }

        .profile-pill { display: flex; align-items: center; gap: 9px; padding: 8px 14px; background: rgba(255,255,255,.55); border: 1px solid var(--border); border-radius: 100px; backdrop-filter: blur(18px); }
        .avatar { width: 36px; height: 36px; display: grid; place-items: center; border-radius: 12px; background: linear-gradient(145deg, #ffd9c7, #ffc09e); font-size: 18px; }

        .hero-card {
            position: relative; padding: 30px; border-radius: 28px;
            background: linear-gradient(120deg, rgba(255,255,255,.75), rgba(255,255,255,.45));
            backdrop-filter: blur(25px); border: 1px solid var(--border);
            box-shadow: 0 25px 65px rgba(82,59,42,.10); margin-bottom: 22px;
        }

        .tag { display: inline-block; padding: 6px 12px; border-radius: 50px; background: rgba(255,218,201,.65); color: #a75942; font-size: 11px; font-weight: 900; }
        .hero-card h2 { margin-top: 12px; font-size: 32px; letter-spacing: -1.2px; }
        .hero-card p { margin-top: 8px; color: var(--muted); font-size: 13px; line-height: 1.6; max-width: 580px; }

        .hero-button {
            display: inline-flex; margin-top: 18px; padding: 12px 18px; border-radius: 13px;
            color: white; background: linear-gradient(135deg, #ff9d7a, #ff7d58);
            font-size: 12px; font-weight: 900; box-shadow: 0 12px 26px rgba(255,138,101,.25);
        }

        .stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 25px; }

        .stat-card {
            padding: 20px; border-radius: 22px; background: var(--glass);
            border: 1px solid var(--border); backdrop-filter: blur(20px);
            box-shadow: 0 18px 45px rgba(79,57,41,.08);
        }

        .stat-title { color: var(--muted); font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: .5px; }
        .stat-value { margin-top: 6px; font-size: 26px; font-weight: 900; }

        .progress-bar { width: 100%; height: 7px; margin-top: 10px; border-radius: 50px; background: rgba(93,72,56,.12); overflow: hidden; }
        .progress-fill { height: 100%; border-radius: inherit; background: linear-gradient(90deg, #ffab8b, #ff7b57); }

        .content-grid { display: grid; grid-template-columns: 1.2fr 0.8fr; gap: 20px; }

        .panel { padding: 24px; border-radius: 24px; background: rgba(255,255,255,.5); backdrop-filter: blur(20px); border: 1px solid var(--border); box-shadow: 0 18px 45px rgba(79,57,41,.08); }
        .panel-heading { display: flex; align-items: center; justify-content: space-between; margin-bottom: 18px; }
        .panel-heading h3 { font-size: 17px; font-weight: 800; }

        .match-card {
            display: flex; align-items: center; gap: 14px; padding: 16px; border-radius: 20px;
            background: rgba(255,255,255,.7); border: 1px solid var(--border); margin-bottom: 12px;
        }

        .match-avatar { width: 48px; height: 48px; display: grid; place-items: center; border-radius: 16px; background: var(--peach); font-size: 24px; flex-shrink: 0; }
        .match-info { flex: 1; }
        .match-info strong { display: block; font-size: 14px; }
        .match-info span { color: var(--muted); font-size: 11px; }

        .score-pill { padding: 6px 12px; border-radius: 50px; background: #D1F2D9; color: #1E6B34; font-size: 11px; font-weight: 900; }

        @media (max-width: 900px) {
            .sidebar { width: 70px; padding: 15px 10px; }
            .sidebar .brand span:not(.brand-icon), .sidebar .menu-title, .sidebar .menu a span:not(.menu-icon) { display: none; }
            .main { margin-left: 90px; padding: 20px; }
            .stats { grid-template-columns: repeat(2, 1fr); }
            .content-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>

<body>

<aside class="sidebar">
    <a class="brand" href="${pageContext.request.contextPath}/dashboard">
        <span class="brand-icon">🏠</span>
        <span>Roommate Matcher</span>
    </a>

    <div class="menu-title">Main Navigation</div>
    <nav class="menu">
        <a href="${pageContext.request.contextPath}/dashboard" class="active">
            <span class="menu-icon">📊</span>
            <span>Dashboard</span>
        </a>
        <a href="${pageContext.request.contextPath}/find-roommate">
            <span class="menu-icon">🔍</span>
            <span>Find Roommates</span>
        </a>
        <a href="${pageContext.request.contextPath}/requests">
            <span class="menu-icon">📬</span>
            <span>Requests</span>
            <% if (pendingRequests > 0) { %>
                <span class="badge-count"><%= com.nestmates.util.HtmlUtil.escape(pendingRequests) %></span>
            <% } %>
        </a>
        <a href="${pageContext.request.contextPath}/profile">
            <span class="menu-icon">👤</span>
            <span>My Profile</span>
        </a>
    </nav>

    <div style="margin-top: auto;">
        <form action="${pageContext.request.contextPath}/logout" method="post">
            <input type="hidden" name="csrfToken" value="<%= com.nestmates.util.HtmlUtil.escape(csrfToken) %>">
            <button type="submit" style="color:#A15440;font-weight:800;font-size:12px;display:flex;align-items:center;gap:8px;padding:10px;border:0;background:none;cursor:pointer;">
                <span>🚪</span> <span>Logout</span>
            </button>
        </form>
    </div>
</aside>

<main class="main">
    <div class="topbar">
        <div class="topbar-left">
            <p>ACTIVE WORKSPACE DASHBOARD</p>
            <h1>Welcome back, <%= com.nestmates.util.HtmlUtil.escape(username) %> 👋</h1>
        </div>
        <div class="profile-pill">
            <div class="avatar">👨🏻‍💻</div>
            <span style="font-weight:800;font-size:12px;"><%= com.nestmates.util.HtmlUtil.escape(email) %></span>
        </div>
    </div>

    <!-- HERO SPOTLIGHT -->
    <div class="hero-card">
        <span class="tag">SMART ROOMMATE MATCHING ACTIVE</span>
        <h2>Find Your Perfect Roommate Today</h2>
        <p>Roommate Matcher calculates high-precision compatibility scores based on everyday habits, cleanliness, noise level, location, and monthly budget.</p>
        <a href="${pageContext.request.contextPath}/find-roommate" class="hero-button">Browse Live Matches →</a>
    </div>

    <!-- STATS GRID -->
    <div class="stats">
        <div class="stat-card">
            <div class="stat-title">Profile Progress</div>
            <div class="stat-value"><%= com.nestmates.util.HtmlUtil.escape(profileProgress) %>%</div>
            <div class="progress-bar"><div class="progress-fill" style="width: <%= com.nestmates.util.HtmlUtil.escape(profileProgress) %>%;"></div></div>
        </div>
        <div class="stat-card">
            <div class="stat-title">Available Matches</div>
            <div class="stat-value"><%= com.nestmates.util.HtmlUtil.escape(matchCount) %></div>
        </div>
        <div class="stat-card">
            <div class="stat-title">Top Compatibility</div>
            <div class="stat-value"><%= com.nestmates.util.HtmlUtil.escape(topMatchScore > 0 ? topMatchScore + "%" : "0%") %></div>
        </div>
        <div class="stat-card">
            <div class="stat-title">Incoming Requests</div>
            <div class="stat-value"><%= com.nestmates.util.HtmlUtil.escape(pendingRequests) %></div>
        </div>
    </div>

    <!-- CONTENT GRID -->
    <div class="content-grid">
        <div class="panel">
            <div class="panel-heading">
                <h3>Recommended Roommate Matches</h3>
                <a href="${pageContext.request.contextPath}/find-roommate" style="color:var(--coral-dark);font-weight:800;font-size:12px;">View All →</a>
            </div>

            <% if (topMatch != null) { %>
                <div class="match-card">
                    <div class="match-avatar"><%= com.nestmates.util.HtmlUtil.escape(topMatch.getOrDefault("avatarEmoji", "👨🏻‍💻")) %></div>
                    <div class="match-info">
                        <strong><%= com.nestmates.util.HtmlUtil.escape(topMatch.get("name")) %></strong>
                        <span>📍 <%= com.nestmates.util.HtmlUtil.escape(topMatch.get("location")) %> &nbsp;·&nbsp; <%= com.nestmates.util.HtmlUtil.escape(topMatch.get("occupation")) %></span>
                    </div>
                    <div class="score-pill">🔥 <%= com.nestmates.util.HtmlUtil.escape(topMatchScore) %>% Match</div>
                </div>
            <% } else { %>
                <p style="color:var(--muted);font-size:13px;padding:12px 0;">No roommate profiles registered yet. Invite your friends to register and get matched live!</p>
            <% } %>
        </div>

        <div class="panel">
            <div class="panel-heading">
                <h3>Quick Actions</h3>
            </div>

            <div style="display:flex;flex-direction:column;gap:10px;">
                <a href="${pageContext.request.contextPath}/find-roommate" style="padding:14px;border-radius:14px;background:rgba(255,217,199,.4);display:flex;align-items:center;gap:12px;font-weight:800;font-size:12px;">
                    <span style="font-size:18px;">🔍</span> Search Roommates by Location
                </a>
                <a href="${pageContext.request.contextPath}/profile" style="padding:14px;border-radius:14px;background:rgba(185,221,243,.4);display:flex;align-items:center;gap:12px;font-weight:800;font-size:12px;">
                    <span style="font-size:18px;">✏️</span> Update Lifestyle Preferences
                </a>
                <a href="${pageContext.request.contextPath}/requests" style="padding:14px;border-radius:14px;background:rgba(205,231,213,.4);display:flex;align-items:center;gap:12px;font-weight:800;font-size:12px;">
                    <span style="font-size:18px;">📬</span> View Connection Requests
                </a>
            </div>
        </div>
    </div>
</main>

</body>
</html>
