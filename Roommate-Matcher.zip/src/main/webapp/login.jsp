<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="com.nestmates.util.HtmlUtil" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roommate Matcher | Member Login</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --bg: #FFF7EF; --text: #29231F; --muted: #756E68;
            --glass: rgba(255,255,255,.55); --glass-strong: rgba(255,255,255,.78);
            --border: rgba(255,255,255,.85); --coral: #FF8A65; --coral-dark: #F47B57;
            --peach: #FFD9C7; --shadow: 0 24px 70px rgba(75,55,40,.10);
        }
        body {
            min-height: 100vh; font-family: Inter, "Segoe UI", Arial, sans-serif;
            color: var(--text);
            background: radial-gradient(circle at 8% 8%, rgba(255,217,199,.46), transparent 24%),
                        radial-gradient(circle at 92% 10%, rgba(185,221,243,.48), transparent 25%), var(--bg);
        }
        a { text-decoration: none; color: inherit; }
        .navbar {
            position: fixed; top: 18px; left: 50%; transform: translateX(-50%);
            width: min(1180px, calc(100% - 30px));
            padding: 11px 13px; display: flex; align-items: center; justify-content: space-between;
            background: var(--glass); backdrop-filter: blur(22px);
            border: 1px solid var(--border); border-radius: 22px; box-shadow: var(--shadow); z-index: 1000;
        }
        .brand { display: flex; align-items: center; gap: 9px; font-size: 20px; font-weight: 900; }
        .brand-icon {
            width: 35px; height: 35px; display: grid; place-items: center;
            border-radius: 12px; background: linear-gradient(145deg, #ffd3b7, #ffab89); font-size: 18px;
        }
        .nav-btn {
            padding: 10px 16px; border-radius: 12px; font-size: 13px; font-weight: 800;
            background: rgba(255,255,255,.52); border: 1px solid rgba(255,255,255,.8); color: #413b37;
        }
        .login-page {
            min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 110px 20px 60px;
        }
        .auth-layout {
            display: grid; grid-template-columns: 1fr 1fr; gap: 40px; width: min(1000px, 100%); align-items: center;
        }
        .auth-intro { padding: 20px 0; }
        .eyebrow {
            display: inline-block; padding: 6px 14px; border-radius: 50px;
            background: rgba(255,220,205,.7); color: #a75942; font-size: 11px; font-weight: 900; letter-spacing: .5px;
        }
        .auth-intro h1 { font-size: clamp(30px,4vw,46px); letter-spacing: -2px; margin-top: 14px; line-height: 1.08; }
        .auth-intro p { color: var(--muted); font-size: 14px; line-height: 1.7; margin-top: 12px; }
        .auth-points { margin-top: 22px; display: flex; flex-direction: column; gap: 11px; }
        .auth-point-item { display: flex; align-items: center; gap: 10px; font-size: 13px; font-weight: 600; }
        .auth-point-icon { width: 24px; height: 24px; display: grid; place-items: center; border-radius: 8px; background: var(--peach); color: #A75942; font-size: 13px; font-weight: 900; flex-shrink: 0; }
        .login-card-box {
            padding: 36px; border-radius: 28px; background: var(--glass-strong);
            backdrop-filter: blur(26px); border: 1px solid var(--border); box-shadow: var(--shadow);
        }
        .auth-icon { font-size: 36px; margin-bottom: 10px; }
        .mini-title { font-size: 10px; font-weight: 900; text-transform: uppercase; letter-spacing: 1px; color: var(--coral-dark); }
        .login-card-box h2 { font-size: 26px; font-weight: 900; margin-top: 6px; letter-spacing: -1px; }
        .login-card-box > p { color: var(--muted); font-size: 13px; margin-top: 4px; margin-bottom: 22px; }
        .form-error { background: rgba(255,200,190,.85); color: #9D3B3B; padding: 12px 14px; border-radius: 12px; margin-bottom: 16px; font-size: 12px; font-weight: 700; }
        .form-success { background: rgba(205,231,213,.85); color: #27643B; padding: 12px 14px; border-radius: 12px; margin-bottom: 16px; font-size: 12px; font-weight: 700; }
        .field { margin-bottom: 16px; }
        label { display: block; margin-bottom: 6px; font-size: 11px; font-weight: 800; }
        .input-wrapper { position: relative; display: flex; align-items: center; }
        .input-icon { position: absolute; left: 13px; font-size: 16px; }
        input[type="email"], input[type="password"] {
            width: 100%; padding: 13px 46px 13px 42px; border-radius: 13px;
            border: 1px solid var(--border); background: rgba(255,255,255,.65);
            color: var(--text); font-family: inherit; font-size: 13px; outline: none;
        }
        input:focus { border-color: var(--coral); box-shadow: 0 0 0 3px rgba(255,138,101,.15); }
        .toggle-password {
            position: absolute; right: 12px; background: none; border: none; cursor: pointer; font-size: 16px;
        }
        .button-primary {
            width: 100%; padding: 14px; border: none; border-radius: 14px; margin-top: 6px;
            background: linear-gradient(135deg, #FF9D7A, #FF7D58); color: white;
            font-family: inherit; font-size: 13px; font-weight: 900; cursor: pointer;
            box-shadow: 0 13px 28px rgba(255,138,101,.24);
        }
        .button-primary:hover { opacity: .93; }
        .form-note { margin-top: 18px; text-align: center; font-size: 12px; color: var(--muted); }
        .form-note a { color: var(--coral-dark); font-weight: 800; }
        @media (max-width: 720px) { .auth-layout { grid-template-columns: 1fr; } .auth-intro { display: none; } }
    </style>
</head>
<body>

<header class="navbar">
    <a class="brand" href="${pageContext.request.contextPath}/index.jsp">
        <span class="brand-icon">🏠</span>
        Roommate Matcher
    </a>
    <div style="margin-left: auto;">
        <a class="nav-btn" href="${pageContext.request.contextPath}/index.jsp">← Back to Home</a>
    </div>
</header>

<main class="login-page">
    <div class="auth-layout">
        <aside class="auth-intro">
            <span class="eyebrow">WELCOME TO Roommate Matcher</span>
            <h1>Find people who make shared living feel easy.</h1>
            <p>Sign in to compare lifestyle habits, discover compatible roommates, and build a better living experience across India.</p>
            <div class="auth-points">
                <div class="auth-point-item">
                    <span class="auth-point-icon">✓</span>
                    <span>Lifestyle &amp; budget-based matching algorithm</span>
                </div>
                <div class="auth-point-item">
                    <span class="auth-point-icon">✓</span>
                    <span>Secure roommate connection requests</span>
                </div>
                <div class="auth-point-item">
                    <span class="auth-point-icon">✓</span>
                    <span>Your preferences, full privacy control</span>
                </div>
            </div>
        </aside>

        <div class="login-card-box">
            <div class="auth-icon">🏠</div>
            <span class="mini-title">MEMBER SIGN IN</span>
            <h2>Welcome back</h2>
            <p>Enter your account credentials to continue.</p>

            <% if (request.getParameter("error") != null) { %>
                <div class="form-error" role="alert">
                    ⚠️ <%= com.nestmates.util.HtmlUtil.escape(request.getParameter("error").replace("+", " ")) %>
                </div>
            <% } %>

            <% if (request.getParameter("success") != null || request.getParameter("registered") != null) { %>
                <div class="form-success" role="status">
                    ✓ Account created successfully! Please sign in below.
                </div>
            <% } %>

            <form id="loginForm" action="${pageContext.request.contextPath}/login" method="post" autocomplete="off">
                <div class="field">
                    <label for="login-email">Email Address</label>
                    <div class="input-wrapper">
                        <span class="input-icon">✉️</span>
                        <input id="login-email" type="email" name="email" placeholder="you@example.com" required autocomplete="off">
                    </div>
                </div>

                <div class="field">
                    <label for="login-password">Password</label>
                    <div class="input-wrapper">
                        <span class="input-icon">🔒</span>
                        <input id="login-password" type="password" name="password" placeholder="Enter your password" required autocomplete="new-password">
                        <button type="button" class="toggle-password" onclick="togglePasswordVisibility('login-password', this)">👁️</button>
                    </div>
                </div>

                <button type="submit" class="button-primary">Login to Dashboard →</button>
            </form>

            <p class="form-note">New to Roommate Matcher? <a href="${pageContext.request.contextPath}/register.jsp">Create an account</a></p>
        </div>
    </div>
</main>

<script>
    function togglePasswordVisibility(id, btn) {
        const input = document.getElementById(id);
        if (input.type === 'password') {
            input.type = 'text';
            btn.textContent = '🙈';
        } else {
            input.type = 'password';
            btn.textContent = '👁️';
        }
    }
</script>
</body>
</html>