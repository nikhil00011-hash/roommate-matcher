<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="com.nestmates.util.HtmlUtil" %>


<%
    java.util.Map<String, Object> profile = (java.util.Map<String, Object>) request.getAttribute("profile");

    if (profile == null) {
        response.sendRedirect(request.getContextPath() + "/profile");
        return;
    }

    String name = String.valueOf(profile.getOrDefault("name", "User"));
    String bio = String.valueOf(profile.getOrDefault("bio", ""));
    String location = String.valueOf(profile.getOrDefault("location", "Not specified"));
    String age = String.valueOf(profile.getOrDefault("age", "18"));
    String occupation = String.valueOf(profile.getOrDefault("occupation", "Student"));
    String sleepSchedule = String.valueOf(profile.getOrDefault("sleepSchedule", "Flexible"));
    String cleanliness = String.valueOf(profile.getOrDefault("cleanliness", "Clean"));
    String smoking = String.valueOf(profile.getOrDefault("smoking", "No"));
    String pets = String.valueOf(profile.getOrDefault("pets", "No Pets"));
    String avatarEmoji = String.valueOf(profile.getOrDefault("avatarEmoji", "👨🏻‍💻"));
    if (avatarEmoji.length() > 8) avatarEmoji = "👨🏻‍💻";
    int budgetMin = 8000, budgetMax = 25000;
    try { budgetMin = (Integer) profile.getOrDefault("budgetMin", 8000); } catch (Exception ignored) {}
    try { budgetMax = (Integer) profile.getOrDefault("budgetMax", 25000); } catch (Exception ignored) {}
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roommate Matcher | My Profile</title>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --bg: #FFF7EF; --text: #29231F; --muted: #756E68;
            --glass: rgba(255,255,255,.55); --glass-strong: rgba(255,255,255,.78);
            --border: rgba(255,255,255,.85); --coral: #FF8A65; --coral-dark: #F47B57;
            --peach: #FFD9C7; --shadow: 0 28px 80px rgba(75,55,40,.12);
        }
        body {
            min-height: 100vh; font-family: Inter, "Segoe UI", Arial, sans-serif;
            color: var(--text); background: radial-gradient(circle at 7% 8%, rgba(255,217,199,.48), transparent 24%), var(--bg);
        }
        a { text-decoration: none; color: inherit; }
        .topbar {
            position: fixed; top: 18px; left: 50%; transform: translateX(-50%);
            width: min(1180px, calc(100% - 30px)); display: flex; align-items: center; justify-content: space-between;
            padding: 10px 16px; background: var(--glass); backdrop-filter: blur(22px);
            border: 1px solid var(--border); border-radius: 20px; box-shadow: var(--shadow); z-index: 100;
        }
        .brand { display: flex; align-items: center; gap: 9px; font-size: 19px; font-weight: 900; }
        .brand-icon { width: 36px; height: 36px; display: grid; place-items: center; border-radius: 12px; background: linear-gradient(145deg, #FFD5C0, #FF9A78); }
        .page { width: min(900px, calc(100% - 30px)); margin: auto; padding: 115px 0 60px; }
        .profile-card {
            padding: 36px; border-radius: 28px; background: var(--glass-strong);
            backdrop-filter: blur(26px); border: 1px solid var(--border); box-shadow: var(--shadow);
        }
        .header-row { display: flex; align-items: center; gap: 20px; margin-bottom: 24px; }
        .avatar { width: 84px; height: 84px; display: grid; place-items: center; border-radius: 24px; background: var(--peach); font-size: 42px; box-shadow: 0 14px 28px rgba(90,60,42,.12); }
        .title-group h1 { font-size: 32px; font-weight: 900; letter-spacing: -1px; }
        .title-group { min-width: 0; }
        .title-group p { color: var(--muted); font-size: 14px; font-weight: 600; line-height: 1.5; margin-top: 4px; overflow-wrap: anywhere; }
        .edit-btn {
            display: inline-flex; margin-left: auto; padding: 12px 20px; border-radius: 14px;
            background: linear-gradient(135deg, #FF9D7A, #FF7D58); color: white;
            font-size: 12px; font-weight: 900; box-shadow: 0 10px 22px rgba(255,138,101,.25);
        }
        .grid-info { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; margin-top: 24px; padding-top: 20px; border-top: 1px solid var(--border); }
        .info-box { padding: 16px; border-radius: 16px; background: rgba(255,255,255,.6); border: 1px solid var(--border); }
        .info-box label { font-size: 10px; font-weight: 800; text-transform: uppercase; color: var(--muted); display: block; margin-bottom: 4px; }
        .info-box span { font-size: 15px; font-weight: 800; }
        .bio-section { margin-top: 24px; padding: 20px; border-radius: 18px; background: rgba(255,255,255,.6); border: 1px solid var(--border); }
        .bio-section h3 { font-size: 14px; font-weight: 800; margin-bottom: 8px; color: var(--muted); }
        .bio-section p { font-size: 14px; line-height: 1.7; }
    </style>
</head>
<body>

<header class="topbar">
    <a class="brand" href="${pageContext.request.contextPath}/dashboard">
        <span class="brand-icon">🏠</span> Roommate Matcher
    </a>
    <a href="${pageContext.request.contextPath}/dashboard" style="font-weight:800;font-size:12px;">← Dashboard</a>
</header>

<main class="page">
    <div class="profile-card">
        <div class="header-row">
            <div class="avatar"><%= com.nestmates.util.HtmlUtil.escape(avatarEmoji) %></div>
            <div class="title-group">
                <h1><%= com.nestmates.util.HtmlUtil.escape(name) %></h1>
                <p>📍 <%= com.nestmates.util.HtmlUtil.escape(location) %> &nbsp;·&nbsp; 🎂 <%= com.nestmates.util.HtmlUtil.escape(age) %> years old &nbsp;·&nbsp; <%= com.nestmates.util.HtmlUtil.escape(occupation) %></p>
            </div>
            <a href="${pageContext.request.contextPath}/create-profile.jsp" class="edit-btn">Edit Profile ✏️</a>
        </div>

        <div class="bio-section">
            <h3>ABOUT ME</h3>
            <p><% if (bio == null || bio.isBlank() || bio.equals("null")) { %>No bio added yet. Click "Edit Profile" to tell roommates about yourself!<% } else { %><%= com.nestmates.util.HtmlUtil.escape(bio) %><% } %></p>
        </div>

        <div class="grid-info">
            <div class="info-box">
                <label>Monthly Budget Range</label>
                <span style="color:#1E6B34;">💵 ₹<%= com.nestmates.util.HtmlUtil.escape(budgetMin) %> - ₹<%= com.nestmates.util.HtmlUtil.escape(budgetMax) %>/month</span>
            </div>
            <div class="info-box">
                <label>Sleep Schedule</label>
                <span>🌙 <%= com.nestmates.util.HtmlUtil.escape(sleepSchedule) %></span>
            </div>
            <div class="info-box">
                <label>Cleanliness Level</label>
                <span>🧹 <%= com.nestmates.util.HtmlUtil.escape(cleanliness) %></span>
            </div>
            <div class="info-box">
                <label>Smoking Preference</label>
                <span>🚭 <%= com.nestmates.util.HtmlUtil.escape(smoking) %></span>
            </div>
            <div class="info-box">
                <label>Pet Preference</label>
                <span>🐾 <%= com.nestmates.util.HtmlUtil.escape(pets) %></span>
            </div>
            <div class="info-box">
                <label>Occupation</label>
                <span>💼 <%= com.nestmates.util.HtmlUtil.escape(occupation) %></span>
            </div>
        </div>
    </div>
</main>

</body>
</html>
