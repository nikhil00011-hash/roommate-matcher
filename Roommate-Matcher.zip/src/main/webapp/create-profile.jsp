<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="com.nestmates.util.HtmlUtil" %>


<%
    if (session.getAttribute("csrfToken") == null) {
        session.setAttribute("csrfToken", java.util.UUID.randomUUID().toString());
    }
    if (session.getAttribute("userId") == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roommate Matcher | Create Profile</title>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        :root {
            --bg: #FFF7EF;
            --text: #29231F;
            --muted: #756E68;
            --glass: rgba(255,255,255,.48);
            --glass-strong: rgba(255,255,255,.68);
            --border: rgba(255,255,255,.78);
            --coral: #FF8A65;
            --coral-dark: #F47B57;
            --blue: #B9DDF3;
            --peach: #FFD9C7;
            --input: rgba(255,255,255,.60);
            --shadow: 0 28px 80px rgba(75,55,40,.12);
        }

        html[data-theme="dark"] {
            --bg: #171513;
            --text: #F8F3EE;
            --muted: #B7ADA5;
            --glass: rgba(38,35,32,.58);
            --glass-strong: rgba(42,39,36,.76);
            --border: rgba(255,255,255,.12);
            --input: rgba(255,255,255,.07);
            --shadow: 0 30px 85px rgba(0,0,0,.40);
        }

        body {
            min-height: 100vh;
            font-family: Inter, "Segoe UI", Arial, sans-serif;
            color: var(--text);
            background:
                radial-gradient(circle at 7% 8%, rgba(255,217,199,.48), transparent 24%),
                radial-gradient(circle at 92% 10%, rgba(185,221,243,.50), transparent 25%),
                var(--bg);
        }

        .topbar {
            position: fixed;
            top: 18px; left: 50%; transform: translateX(-50%);
            width: min(1180px, calc(100% - 30px));
            display: flex; align-items: center; justify-content: space-between;
            padding: 10px 14px;
            background: var(--glass); backdrop-filter: blur(22px);
            border: 1px solid var(--border); border-radius: 20px;
            box-shadow: var(--shadow); z-index: 100;
        }

        .brand { display: flex; align-items: center; gap: 9px; text-decoration: none; color: var(--text); font-size: 19px; font-weight: 900; }
        .brand-icon { width: 36px; height: 36px; display: grid; place-items: center; border-radius: 12px; background: linear-gradient(145deg, #FFD5C0, #FF9A78); }

        .page { width: min(1100px, calc(100% - 30px)); margin: auto; padding: 110px 0 55px; }

        .heading h1 { font-size: clamp(38px, 5vw, 62px); letter-spacing: -3px; }
        .heading h1 span { color: var(--coral); }
        .heading p { color: var(--muted); font-size: 14px; margin-top: 10px; }

        .profile-card { padding: 30px; border-radius: 28px; background: var(--glass-strong); backdrop-filter: blur(26px); border: 1px solid var(--border); box-shadow: var(--shadow); margin-top: 20px; }

        .form-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 18px; }
        .field.full { grid-column: 1 / -1; }

        label { display: block; margin-bottom: 7px; color: var(--text); font-size: 11px; font-weight: 800; }

        input, textarea, select {
            width: 100%; padding: 13px 14px; border-radius: 13px;
            border: 1px solid var(--border); background: var(--input);
            color: var(--text); font-family: inherit; font-size: 12px; outline: none;
        }

        textarea { min-height: 100px; resize: vertical; }

        .avatar-selector { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 6px; }
        .avatar-option {
            width: 44px; height: 44px; display: grid; place-items: center; border-radius: 14px;
            border: 2px solid transparent; background: var(--glass); font-size: 22px; cursor: pointer;
        }
        .avatar-option.selected { border-color: var(--coral); background: var(--peach); }

        .save-button {
            padding: 14px 24px; border: none; border-radius: 14px;
            background: linear-gradient(135deg, #FF9D7A, #FF7D58);
            color: white; font-size: 12px; font-weight: 900; cursor: pointer;
            box-shadow: 0 13px 28px rgba(255,138,101,.24); float: right; margin-top: 20px;
        }
    </style>
</head>

<body>

<header class="topbar">
    <a class="brand" href="${pageContext.request.contextPath}/dashboard">
        <span class="brand-icon">🏠</span> Roommate Matcher
    </a>
    <a class="back-btn" href="${pageContext.request.contextPath}/dashboard" style="text-decoration:none;font-weight:800;font-size:12px;">← Dashboard</a>
</header>

<main class="page">
    <section class="heading">
        <span style="font-weight:900;font-size:11px;color:var(--coral-dark);">CREATE YOUR PROFILE</span>
        <h1>Tell us about <span>you.</span></h1>
        <p>Complete your lifestyle profile to get matched with compatible roommates based on habits and budget.</p>
    </section>

    <section class="profile-card">
        <% if (request.getParameter("error") != null) { %>
            <div style="background:rgba(255,220,220,.8);color:#9D3B3B;padding:12px;border-radius:12px;margin-bottom:18px;font-size:12px;font-weight:700;">
                <%= com.nestmates.util.HtmlUtil.escape(request.getParameter("error")) %>
            </div>
        <% } %>

        <form action="${pageContext.request.contextPath}/save-profile" method="post">
            <input type="hidden" name="csrfToken" value="${sessionScope.csrfToken}">
            <input type="hidden" name="avatarEmoji" id="avatarEmojiInput" value="👨🏻‍💻">

            <div class="form-grid">
                <!-- AVATAR SELECTION -->
                <div class="field full">
                    <label>Choose Your Avatar Emoji</label>
                    <div class="avatar-selector">
                        <div class="avatar-option selected" onclick="selectAvatar('👨🏻‍💻', this)">👨🏻‍💻</div>
                        <div class="avatar-option" onclick="selectAvatar('👩🏻‍💻', this)">👩🏻‍💻</div>
                        <div class="avatar-option" onclick="selectAvatar('🎨', this)">🎨</div>
                        <div class="avatar-option" onclick="selectAvatar('👩🏻‍⚕️', this)">👩🏻‍⚕️</div>
                        <div class="avatar-option" onclick="selectAvatar('🚀', this)">🚀</div>
                        <div class="avatar-option" onclick="selectAvatar('📚', this)">📚</div>
                        <div class="avatar-option" onclick="selectAvatar('💼', this)">💼</div>
                        <div class="avatar-option" onclick="selectAvatar('🔬', this)">🔬</div>
                    </div>
                </div>

                <div class="field">
                    <label>Full Name *</label>
                    <input type="text" name="name" placeholder="Enter your full name" required>
                </div>

                <div class="field">
                    <label>Age *</label>
                    <input type="number" name="age" placeholder="Enter your age" min="18" max="100" required>
                </div>

                <div class="field">
                    <label>Occupation / Major</label>
                    <input type="text" name="occupation" placeholder="e.g. Computer Science Student, Developer">
                </div>

                <div class="field">
                    <label>Preferred Area / Neighbourhood</label>
                    <input type="text" name="location" placeholder="e.g. Koramangala, Andheri, Gachibowli">
                </div>

                <div class="field">
                    <label>Minimum Monthly Budget (₹)</label>
                    <input type="number" name="budgetMin" min="1000" placeholder="e.g. 8000" value="8000">
                </div>

                <div class="field">
                    <label>Maximum Monthly Budget (₹)</label>
                    <input type="number" name="budgetMax" min="1000" placeholder="e.g. 25000" value="25000">
                </div>

                <div class="field">
                    <label>Sleep Schedule</label>
                    <select name="sleepSchedule">
                        <option value="Night Owl">Night Owl</option>
                        <option value="Early Bird">Early Bird</option>
                        <option value="Flexible">Flexible</option>
                    </select>
                </div>

                <div class="field">
                    <label>Cleanliness Habits</label>
                    <select name="cleanliness">
                        <option value="Spotless">Spotless</option>
                        <option value="Very Clean">Very Clean</option>
                        <option value="Clean">Clean</option>
                        <option value="Moderate">Moderate</option>
                    </select>
                </div>

                <div class="field">
                    <label>Smoking Preference</label>
                    <select name="smoking">
                        <option value="No">Non-Smoker</option>
                        <option value="Occasional">Occasional</option>
                        <option value="Yes">Smoker</option>
                    </select>
                </div>

                <div class="field">
                    <label>Pet Preference</label>
                    <select name="pets">
                        <option value="No Pets">No Pets</option>
                        <option value="Dog Friendly">Dog Friendly</option>
                        <option value="Cat Friendly">Cat Friendly</option>
                        <option value="Pets Allowed">Pets Allowed</option>
                    </select>
                </div>

                <div class="field full">
                    <label>Bio & Lifestyle Details</label>
                    <textarea name="bio" placeholder="Tell potential roommates a bit about yourself, interests, study habits, etc."></textarea>
                </div>
            </div>

            <button type="submit" class="save-button">Save Profile & Find Matches →</button>
        </form>
    </section>
</main>

<script>
    function selectAvatar(emoji, el) {
        document.querySelectorAll('.avatar-option').forEach(opt => opt.classList.remove('selected'));
        el.classList.add('selected');
        document.getElementById('avatarEmojiInput').value = emoji;
    }
</script>
</body>
</html>
