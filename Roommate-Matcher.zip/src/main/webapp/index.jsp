<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="com.nestmates.util.HtmlUtil" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Roommate Matcher helps you find roommates who match your lifestyle, habits, and preferences. Smart matching for students and professionals across India.">
    <title>Roommate Matcher | Find Your People</title>
    <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
    <link rel="stylesheet" href="assets/site.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>

<div class="background-orb orb-one"></div>
<div class="background-orb orb-two"></div>
<div class="background-orb orb-three"></div>

<jsp:include page="includes/marketing-nav.jsp">
    <jsp:param name="active" value="home"/>
</jsp:include>

<section class="hero" id="home">
    <div class="hero-content">
        <div class="eyebrow">✨ Smart roommate matching</div>
        <h1>
            Find a place.
            <span class="coral">Find your people.</span>
        </h1>
        <p class="hero-description">
            Match with amazing roommates and find a place you'll love based on
            your lifestyle, habits, and preferences. Built for students and
            professionals looking for their next home.
        </p>
        <div class="hero-actions">
            <a class="hero-button primary-button" href="register.jsp">Find a Roommate →</a>
            <a class="hero-button secondary-button" href="#how">How It Works</a>
        </div>
    </div>

    <div class="hero-visual">
        <div class="scene">
            <div class="floating-shape bubble-one"></div>
            <div class="floating-shape bubble-two"></div>
            <div class="floating-shape bubble-three"></div>

            <img src="assets/hero-house.jpg" alt="Roommate Matcher 3D Antigravity House" class="hero-3d-floating-house">

            <div class="match-card">
                <div class="match-card-top">
                    <div class="avatar">👩🏻</div>
                    <div class="match-info">
                        <strong>Personalized matches</strong>
                        <span>Available after profile setup</span>
                    </div>
                </div>
                <div class="match-score">LIVE MATCHING</div>
            </div>
        </div>
    </div>
</section>

<section class="feature-strip" id="features">
    <div class="feature-card">
        <div class="feature-icon">✨</div>
        <h3>Smart Matching</h3>
        <p>Compatibility scoring based on sleep schedule, cleanliness, smoking, and pet preferences.</p>
    </div>
    <div class="feature-card">
        <div class="feature-icon">🛡</div>
        <h3>Verified Profiles</h3>
        <p>Discover real people with detailed lifestyle profiles you can trust.</p>
    </div>
    <div class="feature-card">
        <div class="feature-icon">🔒</div>
        <h3>Safe &amp; Secure</h3>
        <p>Encrypted passwords and secure sessions keep your account protected.</p>
    </div>
    <div class="feature-card">
        <div class="feature-icon">💬</div>
        <h3>Easy Connect</h3>
        <p>Send roommate requests and connect with compatible matches in seconds.</p>
    </div>
</section>

<section class="how-section" id="how">
    <div class="section-heading">
        <div class="mini-title">Simple process</div>
        <h2>How Roommate Matcher Works</h2>
        <p>Four simple steps to finding someone who fits your lifestyle.</p>
    </div>

    <div class="steps">
        <div class="step">
            <div class="step-circle">👤</div>
            <h3>Create Account</h3>
            <p>Sign up securely and create your Roommate Matcher account in under a minute.</p>
        </div>
        <div class="step">
            <div class="step-circle">📝</div>
            <h3>Create Profile</h3>
            <p>Add your lifestyle, preferences, and room needs for better matches.</p>
        </div>
        <div class="step">
            <div class="step-circle">🔎</div>
            <h3>Find Matches</h3>
            <p>Explore compatible roommate recommendations with match scores.</p>
        </div>
        <div class="step">
            <div class="step-circle">💬</div>
            <h3>Connect</h3>
            <p>Send requests and connect with your potential roommate.</p>
        </div>
    </div>
</section>

<section class="page-section">
    <div class="section-heading">
        <div class="mini-title">Real stories</div>
        <h2>Loved by roommates everywhere</h2>
        <p>See why people choose Roommate Matcher to find their next home.</p>
    </div>

    <div class="testimonials">
        <article class="testimonial-card">
            <p>Build a profile around the habits that matter in shared living, then discover people who are compatible with your routine.</p>
            <div class="testimonial-author">
                <div class="avatar">👨🏽</div>
                <div>
                    <strong>Arjun Mehta</strong>
                    <span>Pune · Software Engineer</span>
                </div>
            </div>
        </article>
        <article class="testimonial-card">
            <p>Your recommendations are generated from real member profiles and your stated preferences — never from placeholder identities.</p>
            <div class="testimonial-author">
                <div class="avatar">👩🏻</div>
                <div>
                    <strong>Priya Sharma</strong>
                    <span>Profile-based discovery</span>
                </div>
            </div>
        </article>
        <article class="testimonial-card">
            <p>"The profile system is simple but thorough. I knew exactly who I was connecting with before sending a request."</p>
            <div class="testimonial-author">
                <div class="avatar">👨🏻</div>
                <div>
                    <strong>Rahul Kapoor</strong>
                    <span>Built for shared living</span>
                </div>
            </div>
        </article>
    </div>
</section>

<section class="cta-banner">
    <h2>Ready to find your nestmate?</h2>
    <p>Join thousands of people looking for roommates who feel like home. Create your free account today.</p>
    <div class="hero-actions" style="justify-content: center;">
        <a class="hero-button primary-button" href="register.jsp">Create Free Account</a>
        <a class="hero-button secondary-button" href="contact.jsp">Contact Us</a>
    </div>
</section>

<jsp:include page="includes/marketing-footer.jsp"/>

<script src="assets/theme.js"></script>
<script src="assets/site.js"></script>
</body>
</html>
