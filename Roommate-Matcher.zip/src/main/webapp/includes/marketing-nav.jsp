<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="com.nestmates.util.HtmlUtil" %>

<%
    String activePage = request.getParameter("active");
    if (activePage == null) activePage = "";
%>
<nav class="navbar" id="siteNav">
    <a class="brand" href="${pageContext.request.contextPath}/">
        <span class="brand-icon">🏠</span>
        Roommate Matcher
    </a>

    <div class="nav-links" id="navLinks">
        <a href="${pageContext.request.contextPath}/" class="<%= com.nestmates.util.HtmlUtil.escape("home".equals(activePage) ? "active" : "") %>">Home</a>
        <a href="${pageContext.request.contextPath}/about.jsp" class="<%= com.nestmates.util.HtmlUtil.escape("about".equals(activePage) ? "active" : "") %>">About</a>
        <a href="${pageContext.request.contextPath}/#features" class="<%= com.nestmates.util.HtmlUtil.escape("features".equals(activePage) ? "active" : "") %>">Features</a>
        <a href="${pageContext.request.contextPath}/#how" class="<%= com.nestmates.util.HtmlUtil.escape("how".equals(activePage) ? "active" : "") %>">How It Works</a>
        <a href="${pageContext.request.contextPath}/contact.jsp" class="<%= com.nestmates.util.HtmlUtil.escape("contact".equals(activePage) ? "active" : "") %>">Contact</a>
    </div>

    <div class="nav-actions">
        <div class="theme-switcher" aria-label="Theme">
            <button type="button" class="theme-btn" data-theme-option="light" title="Light mode">☀️</button>
            <button type="button" class="theme-btn" data-theme-option="system" title="System mode">⚙️</button>
            <button type="button" class="theme-btn" data-theme-option="dark" title="Dark mode">🌙</button>
        </div>
        <a class="nav-btn login-btn" href="login.jsp">Login</a>
        <a class="nav-btn register-btn" href="register.jsp">Register</a>
        <button type="button" class="menu-toggle" id="menuToggle" aria-label="Open menu">☰</button>
    </div>
</nav>
