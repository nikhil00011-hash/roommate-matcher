<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="com.nestmates.util.HtmlUtil" %>
<footer class="site-footer">
    <div class="footer-grid">
        <div class="footer-brand">
            <a class="brand" href="${pageContext.request.contextPath}/">
                <span class="brand-icon">🏠</span>
                Roommate Matcher
            </a>
            <p>
                Find roommates who match your lifestyle, habits, and preferences.
                A smarter way to find a place that feels like home.
            </p>
        </div>

        <div class="footer-col">
            <h4>Product</h4>
            <a href="${pageContext.request.contextPath}/#features">Features</a>
            <a href="${pageContext.request.contextPath}/#how">How It Works</a>
            <a href="register.jsp">Get Started</a>
            <a href="login.jsp">Login</a>
        </div>

        <div class="footer-col">
            <h4>Company</h4>
            <a href="about.jsp">About Us</a>
            <a href="contact.jsp">Contact</a>
            <a href="about.jsp#mission">Our Mission</a>
            <a href="about.jsp#team">Why Roommate Matcher</a>
        </div>

        <div class="footer-col">
            <h4>Support</h4>
            <a href="contact.jsp">Help Center</a>
            <a href="contact.jsp">Safety &amp; Privacy</a>
            <a href="contact.jsp">Report an Issue</a>
            <a href="mailto:support@example.com">support@example.com</a>
        </div>
    </div>

    <div class="footer-bottom">
        © 2026 Roommate Matcher · Find better roommates.
    </div>
</footer>
