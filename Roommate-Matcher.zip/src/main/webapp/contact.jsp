<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="com.nestmates.util.HtmlUtil" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Contact the Roommate Matcher team for support, partnerships, or general inquiries.">
    <title>Roommate Matcher | Contact</title>
    <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
    <link rel="stylesheet" href="assets/site.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>

<div class="background-orb orb-one"></div>
<div class="background-orb orb-two"></div>
<div class="background-orb orb-three"></div>

<jsp:include page="includes/marketing-nav.jsp">
    <jsp:param name="active" value="contact"/>
</jsp:include>

<section class="page-hero">
    <span class="eyebrow">GET IN TOUCH</span>
    <h1>We'd love to <span class="text-coral">hear from you.</span></h1>
    <p>
        Have a question, feedback, or partnership idea? Reach out and our
        team will get back to you as soon as possible.
    </p>
</section>

<section class="contact-layout">
    <aside class="contact-info">
        <h3>Contact Information</h3>

        <div class="info-item">
            <div class="info-item-icon">📧</div>
            <div>
                <strong>Email</strong>
                <span>support@example.com</span>
            </div>
        </div>

        <div class="info-item">
            <div class="info-item-icon">💼</div>
            <div>
                <strong>Partnerships</strong>
                <span>partnerships@example.com</span>
            </div>
        </div>

        <div class="info-item">
            <div class="info-item-icon">📍</div>
            <div>
                <strong>Location</strong>
                <span>Mumbai, Maharashtra, India</span>
            </div>
        </div>

        <div class="info-item">
            <div class="info-item-icon">⏰</div>
            <div>
                <strong>Response Time</strong>
                <span>We typically reply within 24–48 hours on business days.</span>
            </div>
        </div>
    </aside>

    <div class="contact-form">
        <h3 style="margin-bottom: 18px;">Send us a message</h3>

        <% if (request.getParameter("error") != null) { %>
            <div class="message error"><%= com.nestmates.util.HtmlUtil.escape(request.getParameter("error")) %></div>
        <% } %>

        <% if (request.getParameter("success") != null) { %>
            <div class="message success"><%= com.nestmates.util.HtmlUtil.escape(request.getParameter("success")) %></div>
        <% } %>

        <form action="contact" method="post">
            <div class="field">
                <label for="name">Full Name *</label>
                <input type="text" id="name" name="name" placeholder="Your name" required maxlength="100">
            </div>

            <div class="field">
                <label for="email">Email *</label>
                <input type="email" id="email" name="email" placeholder="you@example.com" required maxlength="255">
            </div>

            <div class="field">
                <label for="subject">Subject</label>
                <select id="subject" name="subject">
                    <option value="">Select a topic</option>
                    <option value="General Inquiry">General Inquiry</option>
                    <option value="Account Help">Account Help</option>
                    <option value="Safety Report">Safety Report</option>
                    <option value="Partnership">Partnership</option>
                    <option value="Feedback">Feedback</option>
                </select>
            </div>

            <div class="field">
                <label for="message">Message *</label>
                <textarea id="message" name="message" placeholder="How can we help you?" required maxlength="2000"></textarea>
            </div>

            <button type="submit" class="submit-btn">Send Message</button>
        </form>
    </div>
</section>

<jsp:include page="includes/marketing-footer.jsp"/>

<script src="assets/theme.js"></script>
<script src="assets/site.js"></script>
</body>
</html>
