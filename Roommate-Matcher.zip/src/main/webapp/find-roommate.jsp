<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="com.nestmates.util.HtmlUtil" %>


<%
    if (session.getAttribute("userId") == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }

    java.util.List<java.util.Map<String, Object>> profiles =
            (java.util.List<java.util.Map<String, Object>>) request.getAttribute("profiles");

    if (profiles == null) {
        profiles = java.util.Collections.emptyList();
    }

    String csrfToken = (String) request.getAttribute("csrfToken");
    String flashType = (String) request.getAttribute("flashType");
    String flashMessage = (String) request.getAttribute("flashMessage");
%>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roommate Matcher | Find Roommate</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --bg: #FFF7EF;
            --text: #29231F;
            --muted: #756E68;

            --glass: rgba(255,255,255,.55);
            --glass-strong: rgba(255,255,255,.78);
            --border: rgba(255,255,255,.85);

            --coral: #FF8A65;
            --coral-dark: #F47B57;

            --peach: #FFD9C7;
            --blue: #B9DDF3;
            --yellow: #F6E2B1;
            --green: #CDE7D5;

            --shadow: 0 24px 70px rgba(75,55,40,.10);
        }

        html[data-theme="dark"] {
            --bg: #171513;
            --text: #F8F3EE;
            --muted: #B7ADA5;

            --glass: rgba(38,35,32,.58);
            --glass-strong: rgba(42,39,36,.76);
            --border: rgba(255,255,255,.12);

            --peach: #5B3F35;
            --blue: #294758;
            --yellow: #5A4A2D;
            --green: #304A39;

            --shadow: 0 28px 75px rgba(0,0,0,.35);
        }

        body {
            min-height: 100vh;
            font-family: Inter, "Segoe UI", Arial, sans-serif;
            color: var(--text);
            background:
                radial-gradient(circle at 8% 8%, rgba(255,217,199,.46), transparent 24%),
                radial-gradient(circle at 92% 10%, rgba(185,221,243,.48), transparent 25%),
                radial-gradient(circle at 70% 92%, rgba(246,226,177,.32), transparent 25%),
                var(--bg);
            overflow-x: hidden;
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        /* HEADER */
        .topbar {
            position: fixed;
            top: 18px;
            left: 50%;
            transform: translateX(-50%);
            width: min(1200px, calc(100% - 30px));
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 16px;
            background: var(--glass);
            backdrop-filter: blur(22px);
            border: 1px solid var(--border);
            border-radius: 20px;
            box-shadow: var(--shadow);
            z-index: 100;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 9px;
            font-size: 19px;
            font-weight: 900;
        }

        .brand-icon {
            width: 36px;
            height: 36px;
            display: grid;
            place-items: center;
            border-radius: 12px;
            background: linear-gradient(145deg, #FFD5C0, #FF9A78);
            box-shadow: 0 8px 18px rgba(230,116,78,.16);
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .dashboard-btn {
            padding: 9px 14px;
            border-radius: 11px;
            background: var(--glass-strong);
            border: 1px solid var(--border);
            font-size: 12px;
            font-weight: 800;
        }

        .theme-switcher {
            display: flex;
            gap: 4px;
            padding: 4px;
            border-radius: 50px;
            background: var(--glass-strong);
            border: 1px solid var(--border);
            backdrop-filter: blur(18px);
        }

        .theme-btn {
            width: 31px;
            height: 31px;
            border: none;
            border-radius: 50%;
            background: transparent;
            color: var(--muted);
            cursor: pointer;
            font-size: 13px;
        }

        .theme-btn.active {
            background: var(--coral);
            color: white;
            box-shadow: 0 6px 15px rgba(255,138,101,.25);
        }

        /* PAGE */
        .page {
            width: min(1160px, calc(100% - 30px));
            margin: auto;
            padding: 115px 0 60px;
        }

        .heading {
            margin-bottom: 26px;
        }

        .eyebrow {
            display: inline-flex;
            padding: 8px 14px;
            border-radius: 50px;
            background: var(--glass-strong);
            border: 1px solid var(--border);
            color: var(--coral-dark);
            font-size: 11px;
            font-weight: 900;
            letter-spacing: .5px;
        }

        .heading h1 {
            margin-top: 14px;
            font-size: clamp(38px, 4.5vw, 58px);
            line-height: 1.02;
            letter-spacing: -2.5px;
        }

        .heading h1 span {
            color: var(--coral);
        }

        .heading p {
            max-width: 660px;
            margin-top: 12px;
            color: var(--muted);
            font-size: 14px;
            line-height: 1.7;
        }

        .notice {
            margin: 0 0 22px;
            padding: 12px 14px;
            border-radius: 14px;
            border: 1px solid var(--border);
            font-size: 12px;
            font-weight: 700;
        }

        .notice.success { background: rgba(205, 231, 213, .88); color: #27643B; }
        .notice.info { background: rgba(185, 221, 243, .88); color: #1E5779; }
        .notice.error { background: rgba(255, 217, 199, .88); color: #A3422B; }

        /* SEARCH & FILTER TOOLBAR */
        .filter-toolbar {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr;
            gap: 12px;
            margin-bottom: 24px;
            padding: 14px;
            border-radius: 22px;
            background: var(--glass-strong);
            border: 1px solid var(--border);
            backdrop-filter: blur(20px);
            box-shadow: var(--shadow);
        }

        .filter-control {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .filter-control label {
            font-size: 10px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: .5px;
            color: var(--muted);
        }

        .filter-input, .filter-select {
            padding: 11px 14px;
            border-radius: 12px;
            border: 1px solid var(--border);
            background: var(--glass);
            color: var(--text);
            outline: none;
            font-size: 12px;
            font-weight: 600;
        }

        .filter-input::placeholder {
            color: var(--muted);
        }

        /* GRID */
        .profiles-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 22px;
        }

        /* CARD */
        .profile-card {
            position: relative;
            display: flex;
            flex-direction: column;
            padding: 22px;
            border-radius: 26px;
            background: var(--glass-strong);
            backdrop-filter: blur(24px);
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
            transition: transform .25s ease, box-shadow .25s ease;
        }

        .profile-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 30px 75px rgba(75,55,40,.14);
        }

        .match-badge {
            position: absolute;
            top: 18px;
            right: 18px;
            padding: 6px 12px;
            border-radius: 50px;
            font-size: 10px;
            font-weight: 900;
            letter-spacing: .3px;
        }

        .match-badge.high { background: #D1F2D9; color: #1E6B34; }
        .match-badge.good { background: #FFE4D6; color: #D8562B; }
        .match-badge.medium { background: #D5EBF9; color: #1A5E85; }

        .card-header-row {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 12px;
        }

        .avatar {
            width: 64px;
            height: 64px;
            display: grid;
            place-items: center;
            border-radius: 20px;
            background: linear-gradient(145deg, #FFD9C7, #FFC19D);
            font-size: 32px;
            box-shadow: 0 12px 24px rgba(90,60,42,.10);
            flex-shrink: 0;
        }

        .profile-card h2 {
            font-size: 20px;
            letter-spacing: -.5px;
            font-weight: 800;
        }

        .meta {
            margin-top: 3px;
            color: var(--muted);
            font-size: 11px;
            font-weight: 600;
        }

        .bio {
            margin-top: 10px;
            min-height: 48px;
            color: var(--muted);
            font-size: 12px;
            line-height: 1.6;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .badges {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
            margin-top: 14px;
        }

        .badge {
            padding: 6px 10px;
            border-radius: 50px;
            background: var(--glass);
            border: 1px solid var(--border);
            color: var(--text);
            font-size: 10px;
            font-weight: 700;
        }

        .badge.budget {
            background: rgba(205, 231, 213, .5);
            color: #1E6B34;
            border-color: rgba(205, 231, 213, .8);
        }

        .card-bottom {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            margin-top: auto;
            padding-top: 16px;
            border-top: 1px solid var(--border);
        }

        .occupation {
            color: var(--muted);
            font-size: 11px;
            font-weight: 600;
        }

        .card-actions {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .request-form { margin: 0; }

        .request-btn {
            padding: 9px 14px;
            border-radius: 12px;
            border: none;
            background: linear-gradient(135deg, #FF9D7A, #FF7D58);
            color: white;
            font-family: inherit;
            font-size: 11px;
            font-weight: 900;
            cursor: pointer;
            box-shadow: 0 8px 18px rgba(255,138,101,.22);
            transition: transform .2s ease;
        }

        .request-btn:hover {
            transform: scale(1.03);
        }

        .request-status {
            display: inline-block;
            padding: 8px 13px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 800;
        }

        .request-status.pending { background: #FFE8DF; color: #D8562B; }
        .request-status.connected { background: #D1F2D9; color: #1E6B34; }

        /* EMPTY STATE */
        .empty {
            padding: 60px 25px;
            border-radius: 25px;
            background: var(--glass-strong);
            border: 1px solid var(--border);
            backdrop-filter: blur(20px);
            text-align: center;
            box-shadow: var(--shadow);
        }

        .empty-icon {
            width: 70px;
            height: 70px;
            margin: auto;
            display: grid;
            place-items: center;
            border-radius: 24px;
            background: var(--peach);
            font-size: 30px;
        }

        .empty h2 { margin-top: 16px; font-size: 22px; }
        .empty p { max-width: 500px; margin: 8px auto 0; color: var(--muted); font-size: 13px; line-height: 1.7; }

        @media (max-width: 900px) {
            .filter-toolbar { grid-template-columns: 1fr 1fr; }
            .profiles-grid { grid-template-columns: repeat(2, 1fr); }
        }

        @media (max-width: 600px) {
            .filter-toolbar { grid-template-columns: 1fr; }
            .profiles-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>

<body>

<header class="topbar">
    <a class="brand" href="${pageContext.request.contextPath}/dashboard">
        <span class="brand-icon">🏠</span>
        Roommate Matcher
    </a>

    <div class="header-right">
        <a class="dashboard-btn" href="${pageContext.request.contextPath}/dashboard">← Dashboard</a>

        <div class="theme-switcher">
            <button type="button" class="theme-btn" data-theme="light">☀️</button>
            <button type="button" class="theme-btn" data-theme="system">⚙️</button>
            <button type="button" class="theme-btn" data-theme="dark">🌙</button>
        </div>
    </div>
</header>

<main class="page">

    <section class="heading">
        <span class="eyebrow">SMART LIFESTYLE MATCHING ENGINE</span>
        <h1>Find someone who <span>fits your lifestyle.</span></h1>
        <p>Explore real profiles ranked by compatibility score across sleep schedules, cleanliness habits, location, and budget.</p>
    </section>

    <% if (flashMessage != null && !flashMessage.isBlank()) { %>
        <div class="notice <%= com.nestmates.util.HtmlUtil.escape(flashType) %>" role="status">
            <%= com.nestmates.util.HtmlUtil.escape(flashMessage) %>
        </div>
    <% } %>

    <!-- DYNAMIC MULTI-FILTER TOOLBAR -->
    <section class="filter-toolbar">
        <div class="filter-control">
            <label for="searchInput">Search Candidates</label>
            <input class="filter-input" type="text" id="searchInput" placeholder="Search by name, occupation, or location...">
        </div>

        <div class="filter-control">
            <label for="locationSelect">Location</label>
            <select class="filter-select" id="locationSelect">
                <option value="Any">All Cities</option>
                <option value="Mumbai">Mumbai</option>
                <option value="Delhi">Delhi / NCR</option>
                <option value="Bangalore">Bangalore</option>
                <option value="Hyderabad">Hyderabad</option>
                <option value="Chennai">Chennai</option>
                <option value="Pune">Pune</option>
                <option value="Kolkata">Kolkata</option>
                <option value="Ahmedabad">Ahmedabad</option>
                <option value="Koramangala">Koramangala</option>
                <option value="Andheri">Andheri</option>
                <option value="Gachibowli">Gachibowli</option>
                <option value="Baner">Baner</option>
                <option value="Whitefield">Whitefield</option>
            </select>
        </div>

        <div class="filter-control">
            <label for="scoreSelect">Compatibility</label>
            <select class="filter-select" id="scoreSelect">
                <option value="0">All Matches</option>
                <option value="50">50%+ Match</option>
                <option value="75">75%+ Match</option>
                <option value="90">90%+ Match</option>
            </select>
        </div>

        <div class="filter-control">
            <label for="sleepSelect">Sleep Schedule</label>
            <select class="filter-select" id="sleepSelect">
                <option value="Any">Any Schedule</option>
                <option value="Early Bird">Early Bird</option>
                <option value="Night Owl">Night Owl</option>
                <option value="Flexible">Flexible</option>
            </select>
        </div>
    </section>

    <% if (profiles == null || profiles.isEmpty()) { %>

        <section class="empty">
            <div class="empty-icon">🏠</div>
            <h2>No roommate matches found</h2>
            <p>Try adjusting your search filters or invite new roommates to join Roommate Matcher!</p>
        </section>

    <% } else { %>

        <section class="profiles-grid" id="profilesGrid">

            <% for (java.util.Map<String, Object> profile : profiles) { 
                int score = 0;
                try { score = (Integer) profile.getOrDefault("matchScore", 0); } catch (Exception ignored) {}
                
                String badgeClass = "medium";
                String badgeText = score + "% Match";
                if (score >= 80) { badgeClass = "high"; badgeText = "🔥 " + score + "% Match"; }
                else if (score >= 50) { badgeClass = "good"; badgeText = "✨ " + score + "% Match"; }
                
                String avatar = (String) profile.getOrDefault("avatarEmoji", "👨🏻");
                int budgetMin = 8000, budgetMax = 25000;
                try { budgetMin = (Integer) profile.getOrDefault("budgetMin", 8000); } catch (Exception ignored) {}
                try { budgetMax = (Integer) profile.getOrDefault("budgetMax", 25000); } catch (Exception ignored) {}
            %>

                <article
                    class="profile-card"
                    data-name="<%= com.nestmates.util.HtmlUtil.escape(String.valueOf(profile.getOrDefault("name", ""))) %>"
                    data-location="<%= com.nestmates.util.HtmlUtil.escape(String.valueOf(profile.getOrDefault("location", ""))) %>"
                    data-occupation="<%= com.nestmates.util.HtmlUtil.escape(String.valueOf(profile.getOrDefault("occupation", ""))) %>"
                    data-sleep="<%= com.nestmates.util.HtmlUtil.escape(String.valueOf(profile.getOrDefault("sleepSchedule", ""))) %>"
                    data-score="<%= com.nestmates.util.HtmlUtil.escape(score) %>"
                >
                    <div class="match-badge <%= com.nestmates.util.HtmlUtil.escape(badgeClass) %>"><%= com.nestmates.util.HtmlUtil.escape(badgeText) %></div>

                    <div class="card-header-row">
                        <div class="avatar"><%= com.nestmates.util.HtmlUtil.escape(avatar) %></div>
                        <div>
                            <h2><%= com.nestmates.util.HtmlUtil.escape(profile.get("name")) %></h2>
                            <div class="meta">
                                📍 <%= com.nestmates.util.HtmlUtil.escape(profile.get("location")) %> &nbsp;·&nbsp; 🎂 <%= com.nestmates.util.HtmlUtil.escape(profile.get("age")) %> yrs
                            </div>
                        </div>
                    </div>

                    <div class="bio">
                        <%
                            String bio = String.valueOf(profile.get("bio"));
                            if (bio == null || bio.equals("null") || bio.isBlank()) {
                        %>
                            Looking for a great roommate match on campus.
                        <% } else { %>
                            <%= com.nestmates.util.HtmlUtil.escape(bio) %>
                        <% } %>
                    </div>

                    <div class="badges">
                        <span class="badge budget">💵 ₹<%= com.nestmates.util.HtmlUtil.escape(budgetMin) %>-₹<%= com.nestmates.util.HtmlUtil.escape(budgetMax) %>/month</span>
                        <span class="badge">🌙 <%= com.nestmates.util.HtmlUtil.escape(profile.get("sleepSchedule")) %></span>
                        <span class="badge">🧹 <%= com.nestmates.util.HtmlUtil.escape(profile.get("cleanliness")) %></span>
                        <span class="badge">🚭 <%= com.nestmates.util.HtmlUtil.escape(profile.get("smoking")) %></span>
                        <span class="badge">🐾 <%= com.nestmates.util.HtmlUtil.escape(profile.get("pets")) %></span>
                    </div>

                    <div class="card-bottom">
                        <div class="occupation"><%= com.nestmates.util.HtmlUtil.escape(profile.get("occupation")) %></div>

                        <div class="card-actions">
                            <% String requestStatus = (String) profile.get("requestStatus"); %>

                            <% if ("PENDING".equalsIgnoreCase(requestStatus)) { %>
                                <span class="request-status pending">Request Sent</span>
                            <% } else if ("ACCEPTED".equalsIgnoreCase(requestStatus)) { %>
                                <span class="request-status connected">Connected ✓</span>
                            <% } else { %>
                                <form class="request-form" method="post" action="${pageContext.request.contextPath}/send-request">
                                    <input type="hidden" name="receiverId" value="<%= com.nestmates.util.HtmlUtil.escape(profile.get("userId")) %>">
                                    <input type="hidden" name="csrfToken" value="<%= com.nestmates.util.HtmlUtil.escape(csrfToken) %>">
                                    <button class="request-btn" type="submit">Send Request</button>
                                </form>
                            <% } %>
                        </div>
                    </div>
                </article>

            <% } %>

        </section>

    <% } %>

</main>

<script>
    /* THEME MANAGER */
    const themeKey = "roommate-matcher-for-friends-theme";
    const themeButtons = document.querySelectorAll(".theme-btn");

    function getSystemTheme() {
        return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
    }

    function applyTheme(choice) {
        const actual = choice === "system" ? getSystemTheme() : choice;
        document.documentElement.setAttribute("data-theme", actual);
        themeButtons.forEach(button => {
            button.classList.toggle("active", button.dataset.theme === choice);
        });
        localStorage.setItem(themeKey, choice);
    }

    const savedTheme = localStorage.getItem(themeKey) || "system";
    applyTheme(savedTheme);

    themeButtons.forEach(button => {
        button.addEventListener("click", function () { applyTheme(this.dataset.theme); });
    });

    /* LIVE MULTI-FILTER SCRIPT */
    const searchInput = document.getElementById("searchInput");
    const locationSelect = document.getElementById("locationSelect");
    const scoreSelect = document.getElementById("scoreSelect");
    const sleepSelect = document.getElementById("sleepSelect");
    const profileCards = document.querySelectorAll(".profile-card");

    function filterCards() {
        const query = searchInput ? searchInput.value.toLowerCase().trim() : "";
        const loc = locationSelect ? locationSelect.value.toLowerCase() : "any";
        const minScore = scoreSelect ? parseInt(scoreSelect.value) : 0;
        const sleep = sleepSelect ? sleepSelect.value.toLowerCase() : "any";

        profileCards.forEach(card => {
            const cardName = card.dataset.name.toLowerCase();
            const cardLoc = card.dataset.location.toLowerCase();
            const cardOcc = card.dataset.occupation.toLowerCase();
            const cardSleep = card.dataset.sleep.toLowerCase();
            const cardScore = parseInt(card.dataset.score || "0");

            const matchesQuery = !query || cardName.includes(query) || cardLoc.includes(query) || cardOcc.includes(query);
            const matchesLoc = loc === "any" || cardLoc.includes(loc);
            const matchesScore = cardScore >= minScore;
            const matchesSleep = sleep === "any" || cardSleep.includes(sleep);

            card.style.display = (matchesQuery && matchesLoc && matchesScore && matchesSleep) ? "flex" : "none";
        });
    }

    if (searchInput) searchInput.addEventListener("input", filterCards);
    if (locationSelect) locationSelect.addEventListener("change", filterCards);
    if (scoreSelect) scoreSelect.addEventListener("change", filterCards);
    if (sleepSelect) sleepSelect.addEventListener("change", filterCards);
</script>

</body>
</html>
