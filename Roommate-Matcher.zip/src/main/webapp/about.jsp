<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="com.nestmates.util.HtmlUtil" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Learn about Roommate Matcher — the smart roommate matching platform built for lifestyle compatibility.">
    <title>Roommate Matcher | About Us</title>
    <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
    <link rel="stylesheet" href="assets/site.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>

<div class="background-orb orb-one"></div>
<div class="background-orb orb-two"></div>
<div class="background-orb orb-three"></div>

<jsp:include page="includes/marketing-nav.jsp">
    <jsp:param name="active" value="about"/>
</jsp:include>

<section class="page-hero">
    <span class="eyebrow">OUR STORY</span>
    <h1>Building better <span class="text-coral">shared living.</span></h1>
    <p>
        Roommate Matcher was created to solve a simple problem: finding a roommate
        shouldn't feel like a gamble. We match people based on how they
        actually live — not just where they want to live.
    </p>
</section>

<section class="stats-row">
    <div class="stat-box">
        <strong>REAL</strong>
        <span>Profile-based matching</span>
    </div>
    <div class="stat-box">
        <strong>4</strong>
        <span>Lifestyle signals compared</span>
    </div>
    <div class="stat-box">
        <strong>LIVE</strong>
        <span>Database-backed discovery</span>
    </div>
    <div class="stat-box">
        <strong>SAFE</strong>
        <span>Session-protected accounts</span>
    </div>
</section>

<section class="content-grid" id="mission">
    <article class="content-card">
        <h3>🎯 Our Mission</h3>
        <p>
            We believe everyone deserves a home that feels comfortable — and
            that starts with the people you share it with. Roommate Matcher uses
            lifestyle-based matching to help students, professionals, and
            relocators find roommates who align with their daily habits,
            cleanliness standards, and personal preferences.
        </p>
    </article>
    <article class="content-card">
        <h3>💡 The Problem We Solve</h3>
        <p>
            Traditional roommate searches rely on location and budget alone.
            That leads to mismatched living situations — different sleep
            schedules, conflicting cleanliness expectations, and incompatible
            lifestyles. Roommate Matcher goes deeper with structured profiles and
            compatibility scoring.
        </p>
    </article>
    <article class="content-card full" id="team">
        <h3>🏠 Why Roommate Matcher?</h3>
        <p>
            Our platform combines a beautiful, easy-to-use experience with
            practical matching logic. Create a profile in minutes, browse
            compatible roommates with transparent match scores, and send
            connection requests — all in one place. Whether you're a student
            moving to a new city or a professional sharing an apartment,
            Roommate Matcher helps you find people who feel like home.
        </p>
    </article>
    <article class="content-card">
        <h3>🔒 Safety First</h3>
        <p>
            Account security is built in from day one. Passwords are encrypted
            with industry-standard hashing, sessions expire automatically, and
            your data stays in your control. We're committed to building a
            platform you can trust.
        </p>
    </article>
    <article class="content-card">
        <h3>🌱 Built for India</h3>
        <p>
            Roommate Matcher is designed for the Indian rental market — supporting
            cities like Mumbai, Pune, Bangalore, Delhi, and beyond. Our
            matching considers the realities of shared living in urban India.
        </p>
    </article>
</section>

<section class="cta-banner">
    <h2>Join the Roommate Matcher community</h2>
    <p>Create your profile and start discovering compatible roommates today.</p>
    <div class="hero-actions" style="justify-content: center;">
        <a class="hero-button primary-button" href="register.jsp">Get Started Free</a>
        <a class="hero-button secondary-button" href="contact.jsp">Talk to Us</a>
    </div>
</section>

<jsp:include page="includes/marketing-footer.jsp"/>

<script src="assets/theme.js"></script>
<script src="assets/site.js"></script>
</body>
</html>
